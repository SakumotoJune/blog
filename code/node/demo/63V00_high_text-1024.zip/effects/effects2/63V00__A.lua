local _cameraParams = { 0, 1, 1500, 0, 180, 180, 26.99147 }
local _modelParams = { 0, 0, 0, 0, 0, 180, 1 }
local _cameraPathParam = "Main Camera.gltf"
local _modelPathParam = "63V00__A.gltf"
local _modelCamName = ""
local _materials = {
    { name = "3", path = "hou_uv.png", mask_path = "", texture = nil, width = 2048, height = 2048, color_material = "White_mip.jpg", color_material_width = 512, color_material_height = 512, binary = nil },
    { name = "8", path = "quanbu_uv.png", mask_path = "", texture = nil, width = 2048, height = 2048, color_material = "White_mip.jpg", color_material_width = 512, color_material_height = 512, binary = nil },
    { name = "6", path = "quanbu_uv.png", mask_path = "", texture = nil, width = 2048, height = 2048, color_material = "White_mip.jpg", color_material_width = 512, color_material_height = 512, binary = nil },
    { name = "2", path = "qian_uv.png", mask_path = "", texture = nil, width = 2048, height = 2048, color_material = "White_mip.jpg", color_material_width = 512, color_material_height = 512, binary = nil },
    { name = "1", path = "quanbu_uv.png", mask_path = "", texture = nil, width = 2048, height = 2048, color_material = "White_mip.jpg", color_material_width = 512, color_material_height = 512, binary = nil },
    { name = "7", path = "quanbu_uv.png", mask_path = "", texture = nil, width = 2048, height = 2048, color_material = "White_mip.jpg", color_material_width = 512, color_material_height = 512, binary = nil },
    { name = "4", path = "xiu1_uv.png", mask_path = "", texture = nil, width = 2048, height = 2048, color_material = "White_mip.jpg", color_material_width = 512, color_material_height = 512, binary = nil },
    { name = "5", path = "xiu2_uv.png", mask_path = "", texture = nil, width = 2048, height = 2048, color_material = "White_mip.jpg", color_material_width = 512, color_material_height = 512, binary = nil },
}

-- below code will be generated automatically
--[[
local _modelCamName = ""
local _modelPathParam = ""
local _cameraPathParam = ""
local _modelParams = { PosX, PosY, PosZ, RotX, RotY, RotZ, Scale }
local _cameraParams = { PosX, PosY, PosZ, RotX, RotY, RotZ, FOV }
local _materials = {
    { name = "2", path = "b.png", texture = nil, width = 256, height = 512, trgTex = nil, effectIds = {1,2}, useInput = false, color_material = "white.png", binary = nil },
}
]]

local TAG = "OrangeFilter-GLTF"

local _effectList = {
    -- { path = "xxx.ofeffect", id = 2 }
}

local _renderStatesRestorer = nil
local _world = nil
local _camera = nil
local _sceneCamera = nil
local _modelPath = nil
local _modelPathTarget = nil
local _model = nil
local _cameraModelPath = ""
local _cameraModelPathTarget = nil
local _cameraModel = nil

local _modelPos = nil
local _modelRot = nil
local _Scale = nil
local _dirty = true
local _updateMaterialToken = -1

local _maskTex = nil

local _meshPass = nil
local _mesh_vs = [[
precision highp float;
uniform mat4 uMVP;
attribute vec4 aPosition;
attribute vec4 aTextureCoord;
varying vec2 vTexCoord;
void main()
{
    gl_Position = uMVP * aPosition;
    vTexCoord = aTextureCoord.xy;
}
]]

local _mesh_fs = [[
precision highp float;
uniform sampler2D uTexture0;
varying vec2 vTexCoord;
void main()
{
    gl_FragColor = texture2D(uTexture0, vTexCoord);
}
]]

-- local _maskPass = nil
-- local _mask_vs = [[
--     precision mediump float;
--     attribute vec4 aPosition;
--     attribute vec4 aTextureCoord;
--     varying vec2 vTexCoord;

--     void main() {
--         gl_Position = aPosition;
--         vTexCoord = aTextureCoord.xy;
--     }
-- ]]
-- local _mask_fs = [[
--     precision mediump float;
--     varying vec2 vTexCoord;
--     uniform sampler2D uTexture0;
--     uniform sampler2D uTextureMask;
--     void main() {
--         gl_FragColor = vec4(texture2D(uTexture0, vTexCoord).rgb, texture2D(uTextureMask, vTexCoord).r);
--     }
-- ]]

function initRenderer(context, filter)
    OF_LOGI(TAG, "initRenderer")
    _renderStatesRestorer = RenderStatesRestorer.new()

    _world = World.Create(context)

    _camera = Entity.Create("camera"):addComponentRenderCamera()
    _camera:setLeftHandSpace(true)
    _camera:setClearFlags(OF_CameraClearFlags_DepthOnly)
    _camera:getTransform():setPosition(Vec3f.new(0, 0, -2))
    _camera:getTransform():setRotation(Quaternion.EulerDegree(0, 0, 0))
    _camera:setCullingMask(1)

    Resources.SetResourceDir(filter:resDir())

    _meshPass = context:createCustomShaderPass(_mesh_vs, _mesh_fs)
    -- _maskPass = context:createCustomShaderPass(_mask_vs, _mask_fs)
    return OF_Result_Success
end

function teardownRenderer(context, filter)
    OF_LOGI(TAG, "teardownRenderer")
    for i = 1, #_materials do
        if _materials[i].texture ~= nil then
            context:destroyTexture(_materials[i].texture)
            _materials[i].texture = nil
        end
        if _materials[i].trgTex ~= nil then
            context:releaseTexture(_materials[i].trgTex)
            _materials[i].trgTex = nil
        end
        if _materials[i].maskTexture ~= nil then
            context:destroyTexture(_materials[i].maskTexture)
            _materials[i].maskTexture = nil
        end
        if _materials[i].colorTexture ~= nil then
            context:destroyTexture(_materials[i].colorTexture)
            _materials[i].colorTexture = nil
        end
    end

    _renderStatesRestorer = nil
    World.Destroy(_world)
    _world = nil
    _camera = nil
    _model = nil
    context:destroyCustomShaderPass(_meshPass)
    -- context:destroyCustomShaderPass(_maskPass)
	-- if _maskTex then context:destroyTexture(_maskTex) end

    clearEffectList(context, _effectList)
    return OF_Result_Success
end

function initParams(context, filter)
    filter:insertResParam("ModelPath", OF_ResType_3DMesh, _modelPathParam)
    filter:insertStringParam("ModelPathPlaceHolder", "_")
    filter:insertStringParam("ModelPathString", "")
    filter:insertResParam("CameraPath", OF_ResType_3DMesh, _cameraPathParam)

    for i = 1, #_materials do
        filter:insertResParam(_materials[i].name, OF_ResType_Image, _materials[i].path)
        filter:insertBinaryParam(_materials[i].name .. "_binary", _materials[i].binary)
        if _materials[i].color_material ~= nil then
            filter:insertResParam(_materials[i].name .. "_color_material", OF_ResType_Image, _materials[i].color_material)
        end
        if _materials[i].mask_path ~= nil then
            filter:insertResParam(_materials[i].name .. "_mask", OF_ResType_Image, _materials[i].mask_path)
        end
        filter:insertResArrParam(_materials[i].name .. "_effects", OF_ResType_Effect)
        filter:insertBoolParam(_materials[i].name .. "_use_input", false)
    end
    
    filter:insertFloatParam("TransX", -10000, 10000, _modelParams[1])
    filter:insertFloatParam("TransY", -10000, 10000, _modelParams[2])
    filter:insertFloatParam("ModelPosZ", -10000, 10000, _modelParams[3])
    filter:insertFloatParam("ModelRotX",  0, 360, _modelParams[4])
    filter:insertFloatParam("ModelRotY",  0, 360, _modelParams[5])
    filter:insertFloatParam("Rotate",  0, 360, _modelParams[6])
    filter:insertFloatParam("Scale", 0.1, 10, _modelParams[7])
    filter:insertFloatParam("CameraPosX", -10000, 10000, _cameraParams[1])
    filter:insertFloatParam("CameraPosY", -10000, 10000, _cameraParams[2])
    filter:insertFloatParam("CameraPosZ", -10000, 10000, _cameraParams[3])
    filter:insertFloatParam("CameraRotX", -360, 360, _cameraParams[4])
    filter:insertFloatParam("CameraRotY", -360, 360, _cameraParams[5])
    filter:insertFloatParam("CameraRotZ", -360, 360, _cameraParams[6])
    filter:insertFloatParam("CameraFOV", 1, 179, _cameraParams[7])

    filter:insertResParam("MaskTexture", OF_ResType_Image, "")
    filter:insertIntParam("updateMaterialToken", 0, 99999, 0)

    return OF_Result_Success
end

function clipAndCreate(context, userTex, defWidth, defHeight)
    local userTexWidth, userTexHeight = userTex:width(), userTex:height()
    local newTex = userTex
    if userTexWidth / userTexHeight ~= defWidth / defHeight and false then
        newTex = context:createTexture(defWidth, defHeight)
        context:setViewport(0, 0, defWidth, defHeight)
        context:setBlend(false)
        context:bindFBO(newTex:toOFTexture())

        local scale = 1.0
        if userTexWidth / userTexHeight > defWidth / defHeight then
            scale = defHeight / userTexHeight
        else
            scale = defWidth / userTexWidth
        end

        local mvpMat = Matrix4f:ScaleMat(2 / defWidth, 2 / defHeight, 1.0)
            * Matrix4f:ScaleMat(scale, scale, 1.0)
            * Matrix4f:ScaleMat(0.5 * userTexWidth, 0.5 * userTexHeight, 1.0)

        local quadRender = context:sharedQuadRender()
        _meshPass:use()
        _meshPass:setUniformMatrix4fv("uMVP", 1, false, mvpMat.x)
        _meshPass:setUniformTexture("uTexture0", 0, userTex:textureID(), TEXTURE_2D)
        quadRender:draw(_meshPass, false)

        context:destroyTexture(userTex)
    end
    return newTex
end

function onApplyParams(context, filter)
    local modelPath = filter:resParam("ModelPath")
    local replaceString = filter:stringParam("ModelPathString")
    local placeHolder = filter:stringParam("ModelPathPlaceHolder")
    if string.len(placeHolder) > 0 and string.len(replaceString) > 0 then
        _modelPathTarget = string.gsub(modelPath, placeHolder .. placeHolder, placeHolder .. replaceString .. placeHolder)
    else
        _modelPathTarget = modelPath
    end
    _cameraModelPathTarget = filter:resParam("CameraPath")

	_modelPos = Vec3f.new(filter:floatParam("TransX"), filter:floatParam("TransY"), filter:floatParam("ModelPosZ"))
	_modelRot = Quaternion.EulerDegree(filter:floatParam("ModelRotX"), filter:floatParam("ModelRotY"), filter:floatParam("Rotate"))
    local scale = filter:floatParam("Scale")
    _Scale = Vec3f.new(scale, scale, scale)

    _camera:getTransform():setPosition(
        Vec3f.new(filter:floatParam("CameraPosX"), filter:floatParam("CameraPosY"), filter:floatParam("CameraPosZ")))
    _camera:getTransform():setRotation(
        Quaternion.EulerDegree(filter:floatParam("CameraRotX"), filter:floatParam("CameraRotY"), filter:floatParam("CameraRotZ")))

    _dirty = false
    local materialNeedUpdate = false
    local token = filter:intParam("updateMaterialToken")
    if _updateMaterialToken ~= token then
        _updateMaterialToken = token
        materialNeedUpdate = true
    end 

    for i = 1, #_materials do
        local mtl = _materials[i]
        local binary = filter:binaryParam(mtl.name .. "_binary")
        local path = filter:resParam(mtl.name)
        mtl.effectIds = getEffectIds(context, filter, filter:resArrParam(mtl.name .. "_effects"))
        mtl.useInput = filter:boolParam(mtl.name .. "_use_input")

        -- reset texture
        -- 1、use binary
        -- 2、use path
        if binary ~= nil and binary.format == RGBA and materialNeedUpdate == true then
            local w, h = binary.width, binary.height
            local defWidth, defHeight = mtl.width, mtl.height
            if mtl.texture ~= nil then
              if w ~= defWidth or h ~= defHeight then
                context:destroyTexture(mtl.texture)
                mtl.texture = nil
              end
            end
            if mtl.trgTex ~= nil then
                context:releaseTexture(mtl.trgTex)
                mtl.trgTex = nil
            end
            
            if mtl.texture == nil then
              mtl.texture = context:createTexture(w, h)
            end
            mtl.width, mtl.height = w, h
            mtl.texture:update(0, 0, w, h, binary.data)
            mtl.trgTex = context:getTexture(w, h)
            _dirty = true
            OF_LOGI(TAG, string.format("%s -> use binary %d, %d", mtl.name .. "_binary", w, h))
        elseif path ~= mtl.path or mtl.texture == nil then
            mtl.path = path
            if mtl.texture ~= nil then
                context:destroyTexture(mtl.texture)
                mtl.texture = nil
            end

            if mtl.trgTex ~= nil then
                context:releaseTexture(mtl.trgTex)
                mtl.trgTex = nil
            end

            local fullPath = filter:resFullPath(path)
            local userTex = context:loadTextureFromFile(fullPath, TEXTURE_2D, LINEAR, CLAMP_TO_EDGE, false, false)
            OF_LOGI(TAG, fullPath)
            OF_LOGI(TAG, string.format("%s -> old %d, %d", mtl.name, userTex:width(), userTex:height()))

            -- if user image's ratio is not same with default image,
            -- then clip it and create a new texture
            local defWidth, defHeight = mtl.width, mtl.height
            mtl.texture = clipAndCreate(context, userTex, defWidth, defHeight)
            mtl.trgTex = context:getTexture(defWidth, defHeight)
            _dirty = true
            OF_LOGI(TAG, string.format("%s -> new size %d, %d", mtl.name, mtl.texture:width(), mtl.texture:height()))
        end
        
        -- reset mask texture
        local maskpath = filter:resParam(_materials[i].name .. "_mask")
        if string.len(maskpath) > 0 and (maskpath ~= mtl.mask_path or mtl.maskTexture == nil) then
            mtl.mask_path = maskpath
            if mtl.maskTexture ~= nil then
                context:destroyTexture(mtl.maskTexture)
                mtl.maskTexture = nil
            end
            
            local fullPath = filter:resFullPath(maskpath)
            local userTex = context:loadTextureFromFile(fullPath, TEXTURE_2D, LINEAR, CLAMP_TO_EDGE, false, false)
            OF_LOGI(TAG, fullPath)
            OF_LOGI(TAG, string.format("old %d, %d", userTex:width(), userTex:height()))
            
            mtl.maskTexture = clipAndCreate(context, userTex, mtl.width, mtl.height)
            _dirty = true
            OF_LOGI(TAG, string.format("mask size %d, %d", mtl.maskTexture:width(), mtl.maskTexture:height()))
        end
        
        -- reset color material texture
        local colorpath = filter:resParam(_materials[i].name .. "_color_material")
        if string.len(colorpath) > 0 and (colorpath ~= mtl.color_path or mtl.colorTexture == nil) then
            mtl.color_path = colorpath
            if mtl.colorTexture ~= nil then
                context:destroyTexture(mtl.colorTexture)
                mtl.colorTexture = nil
            end
            
            local fullPath = filter:resFullPath(colorpath)
            local userTex = context:loadTextureFromFile(fullPath, TEXTURE_2D, LINEAR, REPEAT, true, false)
            mtl.colorTexture = clipAndCreate(context, userTex, mtl.color_material_width, mtl.color_material_height)
            _dirty = true
            OF_LOGI(TAG, string.format("reload color texture %s -> %d x %d", fullPath, mtl.color_material_width, mtl.color_material_height))
        end
    end

    -- local mask = filter:resParam("MaskTexture")
    -- if mask ~= nil and string.len(mask) > 0 then
    --     local filePath = filter:resFullPath(mask)
    --     _maskTex = context:loadTextureFromFile(filePath, TEXTURE_2D, LINEAR, CLAMP_TD_EDGE, false, false)
    -- end

    --dumpMaterials()
    return OF_Result_Success
end

function dumpMaterials()
    for i = 1, #_materials do
        local m = _materials[i]
        local ids = m.effectIds
        local s = ""
        for n = 1, #ids do
            s = s .. tostring(ids[n]) .. ","
        end
        print(m.name, m.path, m.texture, m.trgTex, #ids, s, m.useInput)
    end
end

function getEffectIds(context, filter, paths)
    local ids = {}
    for i = 1, #paths do
        local found = false
        for n = 1, #_effectList do
            if _effectList[n].path == paths[i] then
                found = true
                table.insert(ids, _effectList[n].id)
                break
            end
        end

        if not found then
            local effectPath = filter:resFullPath(paths[i])
            effectPath = string.gsub(effectPath, "\\", "/")
            local effectDir = string.match(effectPath, ".*/")
            local effectId = context:createEffectFromFile(effectPath, effectDir)
            if effectId > 0 then
                local info = { id = effectId, path = paths[i] }
                table.insert(_effectList, info)
                table.insert(ids, effectId)
            else
                OF_LOGE(TAG, string.format("Create effect failed. %s", effectPath))
            end
        end
    end
    return ids
end

function clearEffectList(context, effectList)
    local cnt = #effectList
    for i = 1, cnt do
        local idx = cnt - i + 1
        context:destroyEffect(effectList[idx].id)
        table.remove(effectList, idx)
    end
end

function readObject(context, filter, archiveIn)
    return OF_Result_Success
end

function writeObject(context, filter, archiveOut)
    return OF_Result_Success
end

function requiredFrameData(context, filter)
	return { OF_RequiredFrameData_None }
end

function clipTexture(context, inTex, outTex)
    local userTexWidth, userTexHeight = inTex.width, inTex.height
    local defWidth, defHeight = outTex.width, outTex.height

    context:setViewport(0, 0, defWidth, defHeight)
    context:setBlend(false)
    context:bindFBO(outTex)

    local scale = 1.0
    if userTexWidth / userTexHeight > defWidth / defHeight then
        scale = defHeight / userTexHeight
    else
        scale = defWidth / userTexWidth
    end

    local mvpMat = Matrix4f:ScaleMat(2 / defWidth, 2 / defHeight, 1.0)
        * Matrix4f:ScaleMat(scale, scale, 1.0)
        * Matrix4f:ScaleMat(0.5 * userTexWidth, 0.5 * userTexHeight, 1.0)

    local quadRender = context:sharedQuadRender()
    _meshPass:use()
    _meshPass:setUniformMatrix4fv("uMVP", 1, false, mvpMat.x)
    _meshPass:setUniformTexture("uTexture0", 0, inTex.textureID, TEXTURE_2D)
    quadRender:draw(_meshPass, false)
end

function applyBatch(context, idList, frameData, inTex, outTex, debugTex, filterTimestamp)
    local width = inTex.width
    local height = inTex.height
    local cachedTexture = context:getTexture(width, height)
    local tempTex = cachedTexture:toOFTexture()

    local isOddCount = false
    if (#idList % 2) ~= 0 then
        isOddCount = true
    end

    local pIn, pOut = outTex, tempTex
    if isOddCount == true then
        pIn, pOut = tempTex, outTex
    end

    local timestamp = filterTimestamp * 1000
    local t = i64.new(timestamp)
    context:seekEffectAnimation(idList[1], t)

    context:applyRGBA(idList[1], frameData, inTex, pOut, debugTex)

    for i = 2, #idList do
        pIn, pOut = pOut, pIn
        context:seekEffectAnimation(idList[1], t)
        context:applyRGBA(idList[i], frameData, pIn, pOut, debugTex)
    end

    context:releaseTexture(cachedTexture)
end

function applyRGBA(context, filter, frameData, inTex, outTex, debugTex)
    _renderStatesRestorer:save()

    local width = outTex.width
    local height = outTex.height

    if inTex.textureID ~= outTex.textureID then
        context:copyTexture(inTex, outTex)
    end

    -- apply effects to texture
    local updateTexEffect = false
    for i = 1, #_materials do
        local mtl = _materials[i]
        local ids = mtl.effectIds
        if #ids > 0 then
            local srcTexOF = mtl.texture:toOFTexture()
            local tmpTex = context:getTexture(mtl.width, mtl.height)
            if mtl.useInput then
                clipTexture(context, inTex, tmpTex:toOFTexture())
                srcTexOF = tmpTex:toOFTexture()
            end
            local trgTexOF = _materials[i].trgTex:toOFTexture()
            applyBatch(context, ids, frameData, srcTexOF, trgTexOF, debugTex, filter:filterTimestamp())
            updateTexEffect = true
            context:releaseTexture(tmpTex)
        else
            if mtl.useInput then
                clipTexture(context, inTex, mtl.trgTex:toOFTexture())
            end
        end
    end

    context:bindFBOWithSharedDepthTexture(outTex)
    World.Bind(_world)

    if _cameraModelPath ~= _cameraModelPathTarget then
        _cameraModelPath = _cameraModelPathTarget
        if _cameraModel ~= nil then
            Entity.Destroy(_cameraModel)
            _cameraModel = nil
        end

        _cameraModel = Resources.LoadGLTF(_cameraModelPath)
        if _cameraModel ~= nil then
            _sceneCamera = _cameraModel:getComponentRenderCamera()
            if _sceneCamera then
                _sceneCamera:setClearFlags(OF_CameraClearFlags_DepthOnly)
                _sceneCamera:setLeftHandSpace(true)

                local cameraAnim = _cameraModel:getComponentAnimation()
                if cameraAnim then
                    local clipCount = cameraAnim:getClipCount()
                    if clipCount > 0 then
                        local clipName = cameraAnim:getClipName(0)
                        cameraAnim:play(clipName)
                    end
                end

                _camera:setCullingMask(0)
            end
        end
    end

    if _modelPath ~= _modelPathTarget then
        _modelPath = _modelPathTarget

        if _model ~= nil then
            Entity.Destroy(_model)
            _model = nil
            --_sceneCamera = nil
            --_camera:setCullingMask(1)
        end

        _model = Resources.LoadGLTF(_modelPath)
        if _model ~= nil then
            local anim = _model:getComponentAnimation()
            if anim then
                local clipCount = anim:getClipCount()
                if clipCount > 0 then
                    local clipName = anim:getClipName(0)
                    anim:play(clipName)
                end
            end

            local sceneCameraTransform = _model:getTransform():find(_modelCamName)
            if sceneCameraTransform and string.len(_modelCamName) > 0 then
                local cameraEntity = sceneCameraTransform:getEntity()
                _sceneCamera = cameraEntity:getComponentRenderCamera()
                if _sceneCamera then
                    _sceneCamera:setClearFlags(OF_CameraClearFlags_DepthOnly)
                    _sceneCamera:setLeftHandSpace(true)

                    local cameraAnim = cameraEntity:getComponentAnimation()
                    if cameraAnim then
                        local clipCount = cameraAnim:getClipCount()
                        if clipCount > 0 then
                            local clipName = cameraAnim:getClipName(0)
                            cameraAnim:play(clipName)
                        end
                    end

                    _camera:setCullingMask(0)
                end
            end
        end
    end

    if _model ~= nil then
        _model:getTransform():setPosition(_modelPos)
        _model:getTransform():setRotation(_modelRot)
        _model:getTransform():setScale(_Scale)

        if _dirty or updateTexEffect then
            local renderers = _model:getComponentsInChildrenRenderer()
            for i = 1, #renderers do
                local materials = renderers[i]:getMaterials()
                for j = 1, #materials do
                    if materials[j] ~= nil then
                        local matName = materials[j]:getName()
                        for n = 1, #_materials do
                            if _materials[n].name == matName and _materials[n].texture ~= nil then
                                if updateTexEffect and #_materials[n].effectIds > 0 then
                                    local texture = _materials[n].trgTex:toOFTexture()
                                    materials[j]:setTextureOF("_MainTex", texture)
                                    if _materials[n].maskTexture ~= nil then
                                        materials[j]:setTextureOF("_MainTexMask", _materials[n].maskTexture:toOFTexture())
                                    end
                                    if _materials[n].colorTexture ~= nil then
                                        materials[j]:setTextureOF("_ColorMaterial", _materials[n].colorTexture:toOFTexture())
                                    end
                                    
                                else
                                    local texture = _materials[n].texture:toOFTexture()
                                    if _materials[n].useInput then
                                        texture = _materials[n].trgTex:toOFTexture()
                                    end
                                    materials[j]:setTextureOF("_MainTex", texture)
                                    if _materials[n].maskTexture ~= nil then
                                        materials[j]:setTextureOF("_MainTexMask", _materials[n].maskTexture:toOFTexture())
                                    end
                                    if _materials[n].colorTexture ~= nil then
                                        materials[j]:setTextureOF("_ColorMaterial", _materials[n].colorTexture:toOFTexture())
                                    end
                                end
                                break
                            end
                        end
                    end
                end
            end
            _dirty = false
        end
	end

    _camera:setFieldOfView(filter:floatParam("CameraFOV"))

    if _camera:getTargetWidth() ~= width or _camera:getTargetHeight() ~= height then
        _camera:setTargetSize(width, height)
    end

    if _sceneCamera then
        if _sceneCamera:getTargetWidth() ~= width or _sceneCamera:getTargetHeight() ~= height then
            _sceneCamera:setTargetSize(width, height)
        end
    end

    --OF_LOGI(TAG, string.format("frameData.timestamp %f", frameData.timestamp))
    _world:updateWithTime(frameData.timestamp)
    _world:render()
    context:unbindFBOWithDepthBuffer()

	if debugTex ~= nil then
		context:copyTexture(inTex, debugTex)
	end

    _renderStatesRestorer:restore()

    -- if _maskTex then
    --     context:setBlend(true)
    --     context:setViewport(0, 0, outTex.width, outTex.height)
    --     context:bindFBO(outTex)
    --     context:setBlendMode(RS_BlendFunc_SRC_ALPHA, RS_BlendFunc_INV_SRC_ALPHA)

    --     _maskPass:use()
    --     local quadRender = context:sharedQuadRender()
    --     _maskPass:use()
    --     _maskPass:setUniformTexture("uTexture0", 0, outTex:textureID(), TEXTURE_2D)
    --     _maskPass:setUniformTexture("uTextureMask", 0, _maskTex:textureID(), TEXTURE_2D)
    --     quadRender:draw(_maskPass, false)
        
    -- end

    return OF_Result_Success
end
