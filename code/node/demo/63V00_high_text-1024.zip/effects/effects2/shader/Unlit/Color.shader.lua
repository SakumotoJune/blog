vs = [[
    uniform mat4 uMVP;

    attribute vec4 aPosition;

    void main()
    {
        gl_Position = uMVP * aPosition;
    }
]]

fs = [[
    precision highp float;

    uniform vec4 _Color;

    void main()
    {
        gl_FragColor = _Color;
    }
]]

--[[
    Cull
	    Back | Front | Off
    ZTest
	    Less | Greater | LEqual | GEqual | Equal | NotEqual | Always
    ZWrite
	    On | Off
    Blend
	    Off / SrcBlendMode DstBlendMode
	    One Zero SrcColor SrcAlpha DstColor DstAlpha OneMinusSrcColor OneMinusSrcAlpha OneMinusDstColor OneMinusDstAlpha
]]

local rs = {
    Cull = Back,
    ZTest = LEqual,
    ZWrite = On,
    Blend = Off,
    SrcBlendMode = SrcAlpha,
    DstBlendMode = OneMinusSrcAlpha,
    Queue = Geometry,
}

local pass = {
    vs = vs,
    fs = fs,
    rs = rs,
}

-- return pass array
return {
    pass
}
