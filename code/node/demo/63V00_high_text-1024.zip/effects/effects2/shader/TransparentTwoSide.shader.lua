vs = [[
    precision highp float;
    uniform mat4 uMVP;
    uniform vec4 _Time;
    uniform float _FrameCount;
    uniform float _FrameX;
    uniform float _FrameY;
    uniform float _FrameRate;

    attribute vec4 aPosition;
    attribute vec2 aTextureCoord;

    varying vec2 vUV;

    void main()
    {
        gl_Position = uMVP * aPosition;
        if (int(_FrameCount) > 1)
	    {
            int count = int(_FrameX) * int(_FrameY);
            int idx = int(mod(_Time.y * _FrameRate, _FrameX * _FrameY));
            if (idx == count)
                idx = 0;
                
            int rowIdx = int(mod(float(idx) / _FrameX, _FrameY));
            int colIdx = int(mod(float(idx), _FrameX));
        
            vUV.x = aTextureCoord.x / _FrameX + float(colIdx) / _FrameX;
            vUV.y = aTextureCoord.y / _FrameY + float(rowIdx) / _FrameY;
	    }
	    else
	    {
		    vUV = aTextureCoord;
	    }
    }
]]

fs = [[
    precision highp float;

    uniform sampler2D _MainTex;
    uniform sampler2D _MainTexMask;
    uniform sampler2D _BlendTex;
    uniform float _Blend;

    varying vec2 vUV;

    void main()
    {
	
		vec4 main = texture2D(_MainTex, vUV);
        vec4 mask = texture2D(_MainTexMask, vUV);
        vec4 bld = texture2D(_BlendTex, vUV);

        main.a = smoothstep(0.0, 1.0, mask.r);
        vec4 color =mix(main,bld,_Blend);

		if(color.a>0.05)
		{
			gl_FragColor = color;
		}
		else
		{
			discard;
		}
        
    }
]]

--[[
    Cull
	    Back | Front | Off
    ZTest
	    Less | Greater | LEqual | GEqual | Equal | NotEqual | Always
    ZWrite
	    On | Off
    Blend
	    On / SrcBlendMode DstBlendMode
	    One Zero SrcColor SrcAlpha DstColor DstAlpha OneMinusSrcColor OneMinusSrcAlpha OneMinusDstColor OneMinusDstAlpha
]]

local rs_back = {
    Cull = Front,
    ZTest = LEqual,
    ZWrite = On,
    Blend = On,
    SrcBlendMode = SrcAlpha,
    DstBlendMode = OneMinusSrcAlpha,
    Queue = Geometry,
}

local rs_front = {
    Cull = Back,
    ZTest = LEqual,
    ZWrite = On,
    Blend = On,
    SrcBlendMode = SrcAlpha,
    DstBlendMode = OneMinusSrcAlpha,
    Queue = Geometry,
}

local pass_back = {
    vs = vs,
    fs = fs,
    rs = rs_back,
}

local pass_front = {
    vs = vs,
    fs = fs,
    rs = rs_front,
}

-- return pass array
return {
    pass_back,
    pass_front
}
