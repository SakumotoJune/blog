vs = [[
    uniform mat4 uMVP;
    uniform mat4 uWorldMatrix;

    attribute vec4 aPosition;
    attribute vec2 aTextureCoord;
    attribute vec3 aNormal;

    varying vec2 vUV;
    varying vec3 vNormal;

    void main()
    {
        gl_Position = uMVP * aPosition;
        vUV = aTextureCoord;
        vNormal = (uWorldMatrix * vec4(aNormal, 0)).xyz;
    }
]]

fs = [[
    precision highp float;

    uniform sampler2D _MainTex;
    uniform vec4 _Color;
    uniform vec4 uLightColor;
    uniform vec4 uLightDir;

    varying vec2 vUV;
    varying vec3 vNormal;

    void main()
    {
        vec4 c = texture2D(_MainTex, vUV) * _Color;
        float nl = dot(normalize(vNormal), normalize(-uLightDir.xyz));
        c.rgb = c.rgb * uLightColor.rgb * nl;
        gl_FragColor = c;
    }
]]

--[[
    Cull
	    Back | Front | Off
    ZTest
	    Less | Greater | LEqual | GEqual | Equal | NotEqual | Always
    ZWrite
	    On | Off
    Blend
	    Off / SrcBlendMode DstBlendMode
	    One Zero SrcColor SrcAlpha DstColor DstAlpha OneMinusSrcColor OneMinusSrcAlpha OneMinusDstColor OneMinusDstAlpha
]]

local rs = {
    Cull = Back,
    ZTest = LEqual,
    ZWrite = On,
    Blend = Off,
    SrcBlendMode = SrcAlpha,
    DstBlendMode = OneMinusSrcAlpha,
    Queue = Geometry,
}

local pass = {
    vs = vs,
    fs = fs,
    rs = rs,
}

-- return pass array
return {
    pass
}
