vs = [[
#ifndef OF_WASM
    #define OF_WASM 0
#endif

#ifndef SHADOWMAP
    #define SHADOWMAP 0
#endif

#if (SHADOWMAP == 1)
    uniform mat4 uLightViewProjectionMatrix;
    varying vec4 vPosLighProj;
#endif

#if (OF_WASM == 1)
    uniform vec4 uBones[90];
#else
    uniform vec4 uBones[210];
#endif

    uniform mat4 uViewProjectionMatrix;
    uniform vec4 _Time;
    uniform float _FrameCount;
    uniform float _FrameX;
    uniform float _FrameY;
    uniform float _FrameRate;
    uniform vec4 _OffsetSpeed;

    attribute vec4 aPosition;
    attribute vec2 aTextureCoord;
    attribute vec3 aNormal;
    attribute vec4 aTangent;
    attribute vec4 aBlendWeight;
    attribute vec4 aBlendIndex;

    varying vec2 vUV;
    varying vec4 vTSpace0;
    varying vec4 vTSpace1;
    varying vec4 vTSpace2;

    void main()
    {
        mat4 worldMatrix;
        
        // skin mesh
        int index_0 = int(aBlendIndex.x);
        int index_1 = int(aBlendIndex.y);
        int index_2 = int(aBlendIndex.z);
        int index_3 = int(aBlendIndex.w);
        float weights_0 = aBlendWeight.x;
        float weights_1 = aBlendWeight.y;
        float weights_2 = aBlendWeight.z;
        float weights_3 = aBlendWeight.w;
        mat4 bone_0 = mat4(uBones[index_0*3], uBones[index_0*3+1], uBones[index_0*3+2], vec4(0, 0, 0, 1));
        mat4 bone_1 = mat4(uBones[index_1*3], uBones[index_1*3+1], uBones[index_1*3+2], vec4(0, 0, 0, 1));
        mat4 bone_2 = mat4(uBones[index_2*3], uBones[index_2*3+1], uBones[index_2*3+2], vec4(0, 0, 0, 1));
        mat4 bone_3 = mat4(uBones[index_3*3], uBones[index_3*3+1], uBones[index_3*3+2], vec4(0, 0, 0, 1));
        worldMatrix = bone_0 * weights_0 + bone_1 * weights_1 + bone_2 * weights_2 + bone_3 * weights_3;

        // transpose
        {
            float temp = worldMatrix[0][1];
            worldMatrix[0][1] = worldMatrix[1][0];
            worldMatrix[1][0] = temp;

            temp = worldMatrix[0][2];
            worldMatrix[0][2] = worldMatrix[2][0];
            worldMatrix[2][0] = temp;

            temp = worldMatrix[0][3];
            worldMatrix[0][3] = worldMatrix[3][0];
            worldMatrix[3][0] = temp;

            temp = worldMatrix[1][2];
            worldMatrix[1][2] = worldMatrix[2][1];
            worldMatrix[2][1] = temp;

            temp = worldMatrix[1][3];
            worldMatrix[1][3] = worldMatrix[3][1];
            worldMatrix[3][1] = temp;

            temp = worldMatrix[2][3];
            worldMatrix[2][3] = worldMatrix[3][2];
            worldMatrix[3][2] = temp;
        }

        vec4 posWorld = worldMatrix * aPosition;

        gl_Position = uViewProjectionMatrix * posWorld;
        
        if (int(_FrameCount) > 1)
	    {
		    int frame = int(_Time.y * _FrameRate);
		    frame = frame - (frame / int(_FrameCount)) * int(_FrameCount);
		    int x = frame - (frame / int(_FrameX)) * int(_FrameX);
		    int y = frame / int(_FrameX);
		    float w = 1.0 / float(_FrameX);
		    float h = 1.0 / float(_FrameY);

		    vec4 scale_offset;
		    scale_offset.x = w;
		    scale_offset.y = h;
		    scale_offset.z = float(x) * w;
		    scale_offset.w = float(y) * h;

		    vUV = aTextureCoord * scale_offset.xy + scale_offset.zw;
	    }
	    else
	    {
		    vUV = aTextureCoord;
	    }

        vUV += _OffsetSpeed.xy * _Time.y;

        vec3 normal = normalize((worldMatrix * vec4(aNormal, 0)).xyz);
	    vec3 tangent = normalize((worldMatrix * vec4(aTangent.xyz, 0)).xyz);
	    vec3 binormal = normalize(cross(normal, tangent) * aTangent.w);

	    vTSpace0 = vec4(tangent.x, binormal.x, normal.x, posWorld.x);
	    vTSpace1 = vec4(tangent.y, binormal.y, normal.y, posWorld.y);
	    vTSpace2 = vec4(tangent.z, binormal.z, normal.z, posWorld.z);

#if (SHADOWMAP == 1)
        vPosLighProj = uLightViewProjectionMatrix * worldMatrix * aPosition;
#endif
    }
]]
