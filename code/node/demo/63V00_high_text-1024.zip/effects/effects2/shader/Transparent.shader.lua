vs = [[
    precision highp float;
    uniform mat4 uMVP;
    uniform vec4 _Time;
    uniform float _FrameCount;
    uniform float _FrameX;
    uniform float _FrameY;
    uniform float _FrameRate;

    attribute vec4 aPosition;
    attribute vec2 aTextureCoord;

    varying vec2 vUV;

    void main()
    {
        gl_Position = uMVP * aPosition;
        if (int(_FrameCount) > 1)
	    {
            int count = int(_FrameX) * int(_FrameY);
            int idx = int(mod(_Time.y * _FrameRate, _FrameX * _FrameY));
            if (idx == count)
                idx = 0;
                
            int rowIdx = int(mod(float(idx) / _FrameX, _FrameY));
            int colIdx = int(mod(float(idx), _FrameX));
        
            vUV.x = aTextureCoord.x / _FrameX + float(colIdx) / _FrameX;
            vUV.y = aTextureCoord.y / _FrameY + float(rowIdx) / _FrameY;
	    }
	    else
	    {
		    vUV = aTextureCoord;
	    }
    }
]]

fs = [[
    precision highp float;

    uniform sampler2D _MainTex;

    varying vec2 vUV;

    void main()
    {
	
		vec4 color = texture2D(_MainTex, vUV);
		if(color.a>0.05)
		{
			gl_FragColor = color;
		}
		else
		{
			discard;
		}
        
    }
]]

--[[
    Cull
	    Back | Front | Off
    ZTest
	    Less | Greater | LEqual | GEqual | Equal | NotEqual | Always
    ZWrite
	    On | Off
    Blend
	    On / SrcBlendMode DstBlendMode
	    One Zero SrcColor SrcAlpha DstColor DstAlpha OneMinusSrcColor OneMinusSrcAlpha OneMinusDstColor OneMinusDstAlpha
]]

local rs = {
    Cull = Back,
    ZTest = LEqual,
    ZWrite = On,
    Blend = On,
    SrcBlendMode = SrcAlpha,
    DstBlendMode = OneMinusSrcAlpha,
    Queue = Transparent,
}

local pass = {
    vs = vs,
    fs = fs,
    rs = rs,
}

-- return pass array
return {
    pass
}
