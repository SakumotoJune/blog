local shaderFeatures = [[
#ifndef _ALPHATEST_ON
#define _ALPHATEST_ON 0
#endif
#ifndef _LIGHT2_ON
#define _LIGHT2_ON 0
#endif
#ifndef _FRAME_ANIM_ON
#define _FRAME_ANIM_ON 0
#endif
#ifndef _OFFSET_ANIM_ON
#define _OFFSET_ANIM_ON 0
#endif
#ifndef _VIEW_SPACE_LIGHTING_ON
#define _VIEW_SPACE_LIGHTING_ON 0
#endif
#ifndef _NORMALMAP_ON
#define _NORMALMAP_ON 0
#endif
#ifndef _ALPHABLEND_ON
#define _ALPHABLEND_ON 0
#endif
#ifndef _ALPHABLEND_ADD_ON
#define _ALPHABLEND_ADD_ON 0
#endif
#ifndef _CULLOFF_ON
#define _CULLOFF_ON 0
#endif
#ifndef _SKIN_ON
#define _SKIN_ON 0
#endif
#ifndef OF_WASM
#define OF_WASM 0
#endif
#ifndef SHADOWMAP
#define SHADOWMAP 0
#endif
]]

vs = shaderFeatures .. [[
    uniform mat4 uMVP;
    attribute vec3 aPosition;
    attribute vec2 aTextureCoord;
    varying vec2 vTexCoord;
    void main()
    {
        gl_Position = uMVP * vec4( aPosition, 1.0 );
        vTexCoord = aTextureCoord;
    }
]]

fs = shaderFeatures .. [[
    precision highp float;
    uniform sampler2D _MainTex;
    varying vec2 vTexCoord;
    void main()
    {
        gl_FragColor = texture2D(_MainTex, vTexCoord);
    }
]]

--[[
    Cull
	    Back | Front | Off
    ZTest
	    Less | Greater | LEqual | GEqual | Equal | NotEqual | Always
    ZWrite
	    On | Off
    Blend
	    Off / SrcBlendMode DstBlendMode
	    One Zero SrcColor SrcAlpha DstColor DstAlpha OneMinusSrcColor OneMinusSrcAlpha OneMinusDstColor OneMinusDstAlpha
    Queue
        Background | Geometry | AlphaTest | Transparent | Overlay
]]

local rs = {
    Cull = Back,
    ZTest = LEqual,
    ZWrite = On,
    Blend = Off,
    SrcBlendMode = SrcAlpha,
    DstBlendMode = OneMinusSrcAlpha,
    Queue = Geometry,
}

local pass = {
    vs = vs,
    fs = fs,
    rs = rs,
}

-- return pass array
return {
    pass
}
