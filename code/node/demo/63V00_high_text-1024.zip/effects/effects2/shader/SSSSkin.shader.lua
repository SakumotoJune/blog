local shaderFeatures = [[
#ifndef _SSS_ON
#define _SSS_ON 0
#endif
#ifndef _NORMALMAP_ON
#define _NORMALMAP_ON 0
#endif
#ifndef _SKIN_ON
#define _SKIN_ON 0
#endif
#ifndef _BLEND_SHAPE_ON
#define _BLEND_SHAPE_ON 0
#endif
#ifndef OF_WASM
#define OF_WASM 0
#endif
]]

vs = shaderFeatures .. [[
#if (_SKIN_ON == 1)
#if (OF_WASM == 1)
    uniform vec4 uBones[90];
#else
    uniform vec4 uBones[210];
#endif
#endif

    uniform mat4 uWorldMatrix;
    uniform mat4 uViewMatrix;
    uniform mat4 uProjectionMatrix;

    attribute vec4 aPosition;
    attribute vec2 aTextureCoord;
    attribute vec3 aNormal;
    attribute vec4 aTangent;

#if (_SKIN_ON == 1)
    attribute vec4 aBlendWeight;
    attribute vec4 aBlendIndex;
#endif

    varying vec2 vUV;

#if (_NORMALMAP_ON == 1)
    varying vec4 vTSpace0;
    varying vec4 vTSpace1;
    varying vec4 vTSpace2;
#else
    varying vec3 vPos;
    varying vec3 vNormal;
#endif

#if (_BLEND_SHAPE_ON == 1)
    attribute float aVertexIndex;
    uniform sampler2D uBlendShapeTexture;
    uniform sampler2D uBlendShapeWeightTexture;

    int combine_int(vec2 v)
    {
        return int(v.x) * 256 + int(v.y);
    }

    vec4 sample_weight_vec(int i, int w, int h)
    {
        float x = mod(float(i), float(w)) / float(w - 1);
        float y = float(i / w) / float(h - 1);
        return texture2D(uBlendShapeWeightTexture, vec2(x, y));
    }
#endif

    void main()
    {
        vec4 vertex = aPosition;
        vec3 normal = aNormal;
        vec4 tangent = aTangent;

#if (_BLEND_SHAPE_ON == 1)
        {
            vec4 v0 = texture2D(uBlendShapeWeightTexture, vec2(0, 0));
            int weightTextureWidth = combine_int(v0.xy);
            int weightTextureHeight = combine_int(v0.zw);
            vec4 v1 = sample_weight_vec(1, weightTextureWidth, weightTextureHeight);
            int weightCount = combine_int(v1.xy);
            int vertexCount = combine_int(v1.zw);
            vec4 v2 = sample_weight_vec(2, weightTextureWidth, weightTextureHeight);
            int shapeTextureWidth = combine_int(v2.xy);
            int shapeTextureHeight = combine_int(v2.zw);
            int vertexIndex = int(aVertexIndex);

            const int WeightCountMax = 100;
            for (int i = 0; i < WeightCountMax; ++i)
            {
                if (i >= weightCount)
                {
                    break;
                }

                vec4 vi = sample_weight_vec(3 + i, weightTextureWidth, weightTextureHeight);
                int shapeIndex = combine_int(vi.xy);
                float weight = vi.z;

                int vectorIndex = vertexCount * shapeIndex + vertexIndex;
                float x = float(mod(float(vectorIndex), float(shapeTextureWidth))) / float(shapeTextureWidth - 1);
                float y = float(vectorIndex / shapeTextureWidth) / float(shapeTextureHeight - 1);
                vec4 vertexOffset = texture2D(uBlendShapeTexture, vec2(x, y));
                vertex.xyz += vertexOffset.xyz * weight;

                vectorIndex = vertexCount * weightCount + vertexCount * shapeIndex + vertexIndex;
                x = float(mod(float(vectorIndex), float(shapeTextureWidth))) / float(shapeTextureWidth - 1);
                y = float(vectorIndex / shapeTextureWidth) / float(shapeTextureHeight - 1);
                vec4 normalOffset = texture2D(uBlendShapeTexture, vec2(x, y));
                normal.xyz += normalOffset.xyz * weight;

                vectorIndex = vertexCount * weightCount * 2 + vertexCount * shapeIndex + vertexIndex;
                x = float(mod(float(vectorIndex), float(shapeTextureWidth))) / float(shapeTextureWidth - 1);
                y = float(vectorIndex / shapeTextureWidth) / float(shapeTextureHeight - 1);
                vec4 tangentOffset = texture2D(uBlendShapeTexture, vec2(x, y));
                tangent.xyz += tangentOffset.xyz * weight;
            }
        }
#endif

        mat4 worldMatrix;
        
#if (_SKIN_ON == 1)
        // skin mesh
        {
            int index_0 = int(aBlendIndex.x);
            int index_1 = int(aBlendIndex.y);
            int index_2 = int(aBlendIndex.z);
            int index_3 = int(aBlendIndex.w);
            float weights_0 = aBlendWeight.x;
            float weights_1 = aBlendWeight.y;
            float weights_2 = aBlendWeight.z;
            float weights_3 = aBlendWeight.w;
            mat4 bone_0 = mat4(uBones[index_0*3], uBones[index_0*3+1], uBones[index_0*3+2], vec4(0.0, 0.0, 0.0, 1.0));
            mat4 bone_1 = mat4(uBones[index_1*3], uBones[index_1*3+1], uBones[index_1*3+2], vec4(0.0, 0.0, 0.0, 1.0));
            mat4 bone_2 = mat4(uBones[index_2*3], uBones[index_2*3+1], uBones[index_2*3+2], vec4(0.0, 0.0, 0.0, 1.0));
            mat4 bone_3 = mat4(uBones[index_3*3], uBones[index_3*3+1], uBones[index_3*3+2], vec4(0.0, 0.0, 0.0, 1.0));
            worldMatrix = bone_0 * weights_0 + bone_1 * weights_1 + bone_2 * weights_2 + bone_3 * weights_3;
        }

        // transpose
        {
            float temp = worldMatrix[0][1];
            worldMatrix[0][1] = worldMatrix[1][0];
            worldMatrix[1][0] = temp;

            temp = worldMatrix[0][2];
            worldMatrix[0][2] = worldMatrix[2][0];
            worldMatrix[2][0] = temp;

            temp = worldMatrix[0][3];
            worldMatrix[0][3] = worldMatrix[3][0];
            worldMatrix[3][0] = temp;

            temp = worldMatrix[1][2];
            worldMatrix[1][2] = worldMatrix[2][1];
            worldMatrix[2][1] = temp;

            temp = worldMatrix[1][3];
            worldMatrix[1][3] = worldMatrix[3][1];
            worldMatrix[3][1] = temp;

            temp = worldMatrix[2][3];
            worldMatrix[2][3] = worldMatrix[3][2];
            worldMatrix[3][2] = temp;
        }
#else
        worldMatrix = uWorldMatrix;
#endif
        
        gl_Position = uProjectionMatrix * uViewMatrix * worldMatrix * vertex;
        vUV = aTextureCoord;

        mat4 mat = worldMatrix;
        vec3 pos = (mat * vertex).xyz;
        vec3 normalWorld = normalize((mat * vec4(normal, 0.0)).xyz);

#if (_NORMALMAP_ON == 1)
	    vec3 tangentWorld = normalize((mat * vec4(tangent.xyz, 0.0)).xyz);
	    vec3 binormal = normalize(cross(normalWorld, tangentWorld) * tangent.w);

	    vTSpace0 = vec4(tangentWorld.x, binormal.x, normalWorld.x, pos.x);
	    vTSpace1 = vec4(tangentWorld.y, binormal.y, normalWorld.y, pos.y);
	    vTSpace2 = vec4(tangentWorld.z, binormal.z, normalWorld.z, pos.z);
#else
        vPos = pos;
        vNormal = normalWorld;
#endif
    }
]]

fs = shaderFeatures .. [[
    precision highp float;

    uniform vec4 uWorldCameraPos;
    uniform sampler2D _MainTex;
    uniform sampler2D _Normal;
    uniform sampler2D _SpecularAO;
    uniform sampler2D _BeckmannMap;
    uniform samplerCube _IrradianceTex;
    uniform float _Ambient;
    uniform float _SpecularIntensity;
    uniform float _SpecularRoughness;
    uniform float _SpecularFresnel;
    uniform float _ShadowBias;
    uniform float _ShadowTexelSize;

    uniform vec4 _LightDir_0;
    uniform vec4 _LightColor_0;
    uniform mat4 _LightViewProjection_0;
    uniform sampler2D _LightShadow_0;

    uniform vec4 _LightDir_1;
    uniform vec4 _LightColor_1;
    uniform mat4 _LightViewProjection_1;
    uniform sampler2D _LightShadow_1;

#if (_SSS_ON == 1)
    uniform float _SSSWidth;
    uniform float _SSSTranslucency;
#endif

    varying vec2 vUV;

#if (_NORMALMAP_ON == 1)
    varying vec4 vTSpace0;
    varying vec4 vTSpace1;
    varying vec4 vTSpace2;
#else
    varying vec3 vPos;
    varying vec3 vNormal;
#endif

    float ShadowPCF(
        vec3 posWorld,
        int samples,
        float width,
        mat4 lightViewProjection,
        sampler2D lightShadow)
    {
        vec4 pos = lightViewProjection * vec4(posWorld, 1.0);
        pos /= pos.w;
        pos.xyz = pos.xyz * 0.5 + 0.5;
        vec2 uv = pos.xy;
        float z = pos.z - _ShadowBias;

        float shadow = 0.0;
        int offset = (samples - 1) / 2;
        for (int x = -offset; x <= offset; x += 1)
        {
            for (int y = -offset; y <= offset; y += 1)
            {
                vec2 uvOffset = uv + vec2(x, y) * (_ShadowTexelSize * width);
                float d = texture2D(lightShadow, uvOffset).r;
                if (z < d)
                {
                    shadow += 1.0;
                }
                else
                {
                    shadow += 0.0;
                }
            }
        }
        shadow /= float(samples * samples);

        return shadow;
    }

    float Fresnel(vec3 h, vec3 view, float f0)
    {
        float base = 1.0 - dot(view, h);
        float exponential = pow(base, 5.0);
        return exponential + f0 * (1.0 - exponential);
    }

    float SpecularKSK(vec3 normal, vec3 light, vec3 view, float roughness)
    {
        vec3 h = view + light;
        vec3 halfn = normalize(h);

        float ndotl = max(dot(normal, light), 0.0);
        float ndoth = max(dot(normal, halfn), 0.0);

        float ph = pow(2.0 * texture2D(_BeckmannMap, vec2(ndoth, roughness)).r, 10.0);
        float f = mix(0.25, Fresnel(halfn, view, 0.028), _SpecularFresnel);
        float ksk = max(ph * f / dot(h, h), 0.0);

        return ndotl * ksk;
    }

#if (_SSS_ON == 1)
    vec3 SSSSTransmittance(
        vec3 lightDir,
        vec3 normal,
        vec3 posWorld,
        mat4 lightViewProjection,
        sampler2D lightShadow)
    {
        float scale = 8.25 * (1.0 - _SSSTranslucency) / _SSSWidth;
        vec4 shrinkedPos = vec4(posWorld - 0.005 * normal, 1.0);
        vec4 pos = lightViewProjection * shrinkedPos;
        pos /= pos.w;
        pos.xyz = pos.xyz * 0.5 + 0.5;
        float d1 = 1.0 - texture2D(lightShadow, pos.xy).r;
        float d2 = 1.0 - pos.z;
        float d = scale * abs(d1 - d2);
        float dd = -d * d;
        vec3 profile = vec3(0.233, 0.455, 0.649) * exp(dd / 0.0064) +
            vec3(0.1, 0.336, 0.344) * exp(dd / 0.0484) +
            vec3(0.118, 0.198, 0.0)   * exp(dd / 0.187) +
            vec3(0.113, 0.007, 0.007) * exp(dd / 0.567) +
            vec3(0.358, 0.004, 0.0)   * exp(dd / 1.99) +
            vec3(0.078, 0.0, 0.0)   * exp(dd / 7.41);
        return profile * max(0.3 + dot(lightDir, -normal), 0.0);
    }
#endif

    vec3 light(
        vec3 lightDir,
        vec3 lightColor,
        vec3 normal,
        vec3 normalNoBump,
        vec3 viewDir,
        float intensity,
        float roughness,
        vec3 albedo,
        vec3 posWorld,
        mat4 lightViewProjection,
        sampler2D lightShadow)
    {
        float shadow = ShadowPCF(posWorld, 3, 1.0, lightViewProjection, lightShadow);

        vec3 f2 = albedo * lightColor;
        float nl = max(dot(normal, lightDir), 0.0);
        vec3 diffuse = shadow * f2 * nl;
        float spec = intensity * SpecularKSK(normal, lightDir, viewDir, roughness);
        vec3 specular = shadow * spec * lightColor;
        vec3 color = diffuse + specular;

#if (_SSS_ON == 1)
        color += f2 * SSSSTransmittance(
            lightDir,
            normalNoBump,
            posWorld,
            lightViewProjection,
            lightShadow);
#endif

        return color;
    }

    void main()
    {
	    vec2 uv = vUV;
	    vec4 c = texture2D(_MainTex, uv);
        c = pow(c, vec4(2.2));

        vec3 specularAO = texture2D(_SpecularAO, uv).rgb;
        float occlusion = specularAO.b;
        float intensity = specularAO.r * _SpecularIntensity;
        float roughness = (specularAO.g / 0.3) * _SpecularRoughness;

#if (_NORMALMAP_ON == 1)
	    vec3 n = texture2D(_Normal, uv).rgb * 2.0 - 1.0;
        n.z = sqrt(1.0 - max(dot(n.xy, n.xy), 0.0));
	    vec3 normal = normalize(vec3(dot(vTSpace0.xyz, n), dot(vTSpace1.xyz, n), dot(vTSpace2.xyz, n)));
        vec3 pos = vec3(vTSpace0.w, vTSpace1.w, vTSpace2.w);
        vec3 normalNoBump = normalize(vec3(vTSpace0.z, vTSpace1.z, vTSpace2.z));
#else
        vec3 normal = normalize(vNormal);
        vec3 pos = vPos;
        vec3 normalNoBump = normal;
#endif

        vec3 viewDir = normalize(uWorldCameraPos.xyz - pos);

        vec4 color = vec4(0.0);

        // light
        color.rgb += light(
            normalize(-_LightDir_0.xyz),
            _LightColor_0.rgb,
            normal,
            normalNoBump,
            viewDir,
            intensity,
            roughness,
            c.rgb,
            pos,
            _LightViewProjection_0,
            _LightShadow_0);
        color.rgb += light(
            normalize(-_LightDir_1.xyz),
            _LightColor_1.rgb,
            normal,
            normalNoBump,
            viewDir,
            intensity,
            roughness,
            c.rgb,
            pos,
            _LightViewProjection_1,
            _LightShadow_1);

        vec3 irradiance = textureCube(_IrradianceTex, normal).rgb;
        color.rgb += occlusion * _Ambient * c.rgb * irradiance;
        color.a = c.a;

        gl_FragColor = color;
    }
]]

--[[
    Cull
	    Back | Front | Off
    ZTest
	    Less | Greater | LEqual | GEqual | Equal | NotEqual | Always
    ZWrite
	    On | Off
    Blend
	    Off / SrcBlendMode DstBlendMode
	    One Zero SrcColor SrcAlpha DstColor DstAlpha OneMinusSrcColor OneMinusSrcAlpha OneMinusDstColor OneMinusDstAlpha
    Queue
        Background | Geometry | AlphaTest | Transparent | Overlay
]]

local rs = {
    Cull = Back,
    ZTest = LEqual,
    ZWrite = On,
    Blend = Off,
    SrcBlendMode = SrcAlpha,
    DstBlendMode = OneMinusSrcAlpha,
    Queue = Geometry,
}

local pass = {
    vs = vs,
    fs = fs,
    rs = rs,
}

-- return pass array
return {
    pass
}
