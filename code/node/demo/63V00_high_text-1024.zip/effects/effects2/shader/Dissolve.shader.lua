vs = [[
    uniform mat4 uMVP;
    attribute vec2 aTextureCoord;
    attribute vec3 aPosition;

    // uniform mat4 uWorldMatrix;
    // uniform mat4 uViewMatrix;
    // uniform mat4 uProjectionMatrix;

    varying vec2 vUV;

    void main()
    {
        //vec4 vertex = aPosition;
        //gl_Position = uProjectionMatrix * uViewMatrix * uWorldMatrix * vertex;

        gl_Position = uMVP * vec4(aPosition, 1.0);
        vUV = aTextureCoord;
    }
]]





fs = [[
    precision highp float;
    uniform sampler2D _MainTex;
    uniform float _Strength;
    uniform float _Times;
    uniform float _TimingStart;
    uniform float _NoiseContrast;
    uniform float _NoiseDenseness;
    uniform float _Edge;
    uniform vec4 _EdgeColor;
    uniform vec4 _Time;
    varying vec2 vUV;

    //random hash函数 frac函数返回标量或每个矢量中各分量的小数部分
    vec2 hash22(vec2 p) {
        p = vec2(dot(p,vec2(127.1,311.7)),dot(p,vec2(269.5,183.3)));
        return -1.0 + 2.0*fract(sin(p)*43758.5453123);
    }

    //simplex 噪声
    float simplex_noise(vec2 p) {
        float k1 = 0.366025404;     // (sqrt(3)-1)/2;
        float k2 = 0.211324865;     // (3-sqrt(3))/6;
        vec2 i = floor(p + (p.x + p.y)*k1);
        vec2 a = p - (i - (i.x + i.y)*k2);
        vec2 o = (a.x < a.y) ? vec2(0.0, 1.0) : vec2(1.0, 0.0);
        vec2 b = a - o + k2;
        vec2 c = a - 1.0 + 2.0*k2;
        vec3 h = max(0.5 - vec3(dot(a, a), dot(b, b), dot(c, c)), 0.0);
        vec3 n = h * h*h*h*vec3(dot(a, hash22(i)), dot(b, hash22(i + o)), dot(c, hash22(i + 1.0)));
        return dot(vec3(70.0, 70.0, 70.0), n);
    }

    //分形叠加fbm 就是把不同的随机点以某种平滑方式“连”起来
    float noise_sum_simplex(vec2 p) {
        float f = 0.0;
        p = p * 4.0;        //叠加了5层，并把初始化采样距离设置为4
        f += 1.0*simplex_noise(p);
        p = 2.0*p;
        f += 0.5*simplex_noise(p);
        p = 2.0*p;
        f += 0.25*simplex_noise(p);
        p = 2.0*p;
        f += 0.125*simplex_noise(p);
        p = 2.0*p;
        f += 0.0625*simplex_noise(p);
        return f;
    }

    //进行绝对值操作，因此会在0值变化处出现不连续性，形成一些尖锐的效果模拟火焰、云朵 -turbulence 湍流
    float noise_sum_abs_simplex(vec2 p) {
        float f = 0.0;
        p = p * 7.0;
        f += 1.0*abs(simplex_noise(p));
        p = 2.0*p;
        f += 0.5*abs(simplex_noise(p));
        p = 2.0*p;
        f += 0.25*abs(simplex_noise(p));
        p = 2.0*p;
        f += 0.125*abs(simplex_noise(p));
        p = 2.0*p;
        f += 0.0625*abs(simplex_noise(p));
        return f;
    }

    float noise_sum_abs_sin_simplex(vec2 p) {
        float f = 0.0;
        p = p * 16.0;
        f += 1.0*abs(simplex_noise(p));
        p = 2.0*p;
        f += 0.5*abs(simplex_noise(p));
        p = 2.0*p;
        f += 0.25*abs(simplex_noise(p));
        p = 2.0*p;
        f += 0.125*abs(simplex_noise(p));
        p = 2.0*p;
        f += 0.0625*abs(simplex_noise(p));
        p = 2.0*p;
        f = sin(f + p.x / 32.0);
        return f;
    }


    void main()
    {
        vec2 uv = vUV;

        //通过simplex 噪声生成噪声纹理
        float partNine =0.0;
        float partTen =1.0; 
        float partEleven =0.0;
        float partTwelve = 0.0;

        float value9 = simplex_noise(uv);
        float value10 = noise_sum_simplex(uv*_NoiseDenseness);
        float value11 = noise_sum_abs_simplex(uv);
        float value12 = noise_sum_abs_sin_simplex(uv);
        float val = value9 * partNine + value10 * partTen  + value11 * partEleven + value12 * partTwelve; //value10 * partTen有效
        val = val * _NoiseContrast + 0.45; //val * A + B A变越大越浓 B越大越淡

        //溶解
	    vec4 col = texture2D(_MainTex, uv);
        vec4 noise_col=vec4(val, val, val, 1);
        float timing_start = _TimingStart;
        float t=_TimingStart;
        timing_start = timing_start -_Time.y;
        
        if(timing_start<0.001){
            float strength = (_Time.y-t) /int(_Times) + _Strength;
            float s = noise_col.r - strength;
            if(s < 0.001)
            {
               discard;         // 如果小于阈值，就抛弃该片断
            } 
            (s>_Edge) ? (col=col):(col = _EdgeColor);

        }
       
        
        //bvec2 test = bvec2(s < 0.001, s > _Edge);    
        //if (!all(test))        
        //        col = _EdgeColor;

        gl_FragColor = col;

    }
]]


--[[
    Cull
	    Back | Front | Off
    ZTest
	    Less | Greater | LEqual | GEqual | Equal | NotEqual | Always
    ZWrite
	    On | Off
    Blend
	    Off / SrcBlendMode DstBlendMode
	    One Zero SrcColor SrcAlpha DstColor DstAlpha OneMinusSrcColor OneMinusSrcAlpha OneMinusDstColor OneMinusDstAlpha
    Mask
        RGBA | RGB | Alpha | Zero
]]

local rs = {
    Cull = Back,
    ZTest = LEqual,
    ZWrite = On,
    Blend = Off,
    SrcBlendMode = SrcAlpha,
    DstBlendMode = OneMinusSrcAlpha,
    Queue = Geometry,
}

local pass = {
    vs = vs,
    fs = fs,
    rs = rs,
}

-- return pass array
return {
    pass
}

