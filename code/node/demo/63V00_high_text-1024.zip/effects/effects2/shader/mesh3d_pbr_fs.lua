fs = [[
    precision highp float;

    uniform sampler2D _MainTex;
    uniform sampler2D _Normal;
    uniform sampler2D _SpecMap;
    uniform sampler2D _EmissiveMap;
    uniform samplerCube _CubeMap;

    uniform vec4 _Color;
    uniform vec4 _Spec;
    uniform vec4 _Emissive;
    uniform vec4 _LightDir;
    uniform vec4 _LightColor;
    uniform vec4 _AmbientColor;
    uniform vec4 _EnvColor;
    uniform vec4 _DissBorderColor1;
    uniform vec4 _DissBorderColor2;
    uniform float _Smoothness;

    varying vec2 vUV;
    varying vec4 vTSpace0;
    varying vec4 vTSpace1;
    varying vec4 vTSpace2;

    vec2 pow4(vec2 x) { return x * x * x * x; }
	
	vec4 GI(vec4 base, vec4 c, vec3 normal, vec3 viewDir)
	{
		vec2 uv = vUV;
	    vec4 specMap = texture2D(_SpecMap, uv);
	    vec3 emissive = texture2D(_EmissiveMap, uv).rgb * _Emissive.rgb * base.rgb;
	    vec3 lightDir = normalize(-_LightDir.xyz);			
	    vec3 lightColor = _LightColor.rgb;
	    float nl = max(dot(normal, lightDir), 0.0);
	    vec3 h = normalize(lightDir + viewDir);
	    float nh = max(dot(normal, h), 0.0);
	    float nv = max(dot(normal, viewDir), 0.0);
	    vec3 ref = reflect(viewDir, normal);

	    vec3 specColor = _Spec.rgb * specMap.rgb;
	    float smoothness = _Smoothness * specMap.a;
	    float reflectivity = max(max(specColor.r, specColor.g), specColor.b);

	    vec2 rlp4 = pow4(vec2(dot(ref, lightDir), 1.0 - nv));
	    float fresnel = rlp4.y;
	    float grazing = clamp(smoothness + reflectivity, 0.0, 1.0);

	    float lh = max(dot(lightDir, h), 0.0);
	    float roughness = 1.0 - smoothness;
	    float roughness2 = roughness * roughness;
	    float a = roughness2;
	    float a2 = a * a;
	    float d = nh * nh * (a2 - 1.0) + 1.00001;
	    float spec = a2 / (max(0.1, lh * lh) * (roughness2 + 0.5) * (d * d) * 4.0);
	    spec = max(spec - 1e-4, 0.0);
	    ref.y = -ref.y;
	    vec3 env = textureCube(_CubeMap, -ref).rgb * _EnvColor.rgb * 2.0;
	    vec3 diffuse = c.rgb * _AmbientColor.rgb + c.rgb * nl * lightColor;
	    vec3 specular = spec * specColor * lightColor;
	    vec3 gi = env * mix(specColor, vec3(1.0) * grazing, fresnel);
	    c.rgb = diffuse * (1.0 - reflectivity) + specular + gi + emissive;
        return c;
	}
		
	vec4 pbr()
    {
	    vec2 uv = vUV;
	    vec4 base = texture2D(_MainTex, uv);
        vec4 c = base * _Color;
		
	    vec3 posView = vec3(vTSpace0.w, vTSpace1.w, vTSpace2.w);
		vec3 n = texture2D(_Normal, uv).rgb * 2.0 - 1.0;
	    vec3 normal = normalize(vec3(dot(vTSpace0.xyz, n), dot(vTSpace1.xyz, n), dot(vTSpace2.xyz, n)));
	    vec3 viewDir = normalize(-posView);
			
		return GI(base, c, normal, viewDir);
    }
		
]]
