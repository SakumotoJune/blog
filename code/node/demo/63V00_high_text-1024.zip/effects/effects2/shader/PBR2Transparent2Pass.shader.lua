local shaderFeatures = [[
#ifndef _ALPHATEST_ON
#define _ALPHATEST_ON 0
#endif
#ifndef _LIGHT2_ON
#define _LIGHT2_ON 0
#endif
#ifndef _FRAME_ANIM_ON
#define _FRAME_ANIM_ON 0
#endif
#ifndef _OFFSET_ANIM_ON
#define _OFFSET_ANIM_ON 0
#endif
#ifndef _NORMALMAP_ON
#define _NORMALMAP_ON 0
#endif
#ifndef _ALPHABLEND_ON
#define _ALPHABLEND_ON 0
#endif
#ifndef _ALPHABLEND_ADD_ON
#define _ALPHABLEND_ADD_ON 0
#endif
#ifndef _CULLOFF_ON
#define _CULLOFF_ON 0
#endif
#ifndef _SKIN_ON
#define _SKIN_ON 0
#endif
#ifndef _BLEND_SHAPE_ON
#define _BLEND_SHAPE_ON 0
#endif
#ifndef OF_WASM
#define OF_WASM 0
#endif
#ifndef SHADOWMAP
#define SHADOWMAP 0
#endif
]]

vs = shaderFeatures .. [[
#if (_SKIN_ON == 1)
#if (OF_WASM == 1)
    uniform vec4 uBones[90];
#else
    uniform vec4 uBones[210];
#endif
#endif
    
    uniform mat4 uWorldMatrix;
    uniform mat4 uViewMatrix;
    uniform mat4 uProjectionMatrix;

    uniform vec4 _Time;

	uniform vec4 _UVScaleOffset;

#if (_FRAME_ANIM_ON == 1)
    uniform float _FrameCount;
    uniform float _FrameX;
    uniform float _FrameY;
    uniform float _FrameRate;
#endif

#if (_OFFSET_ANIM_ON == 1)
    uniform vec4 _OffsetSpeed;
#endif

    in vec4 aPosition;
    in vec2 aTextureCoord;
    in vec3 aNormal;
    in vec4 aTangent;

#if (_SKIN_ON == 1)
    in vec4 aBlendWeight;
    in vec4 aBlendIndex;
#endif

    out vec2 vUV;

#if (_NORMALMAP_ON == 1)
    out vec4 vTSpace0;
    out vec4 vTSpace1;
    out vec4 vTSpace2;
#else
    out vec3 vPos;
    out vec3 vNormal;
#endif

#if (SHADOWMAP == 1)
    uniform mat4 uLightViewProjectionMatrix;
    out vec4 vPosLighProj;
#endif

#if (_BLEND_SHAPE_ON == 1)
    in float aVertexIndex;
    uniform sampler2D uBlendShapeTexture;
    uniform sampler2D uBlendShapeWeightTexture;

    int combine_int(vec2 v)
    {
        return int(v.x) * 256 + int(v.y);
    }

    vec4 sample_weight_vec(int i, int w, int h)
    {
        float x = mod(float(i), float(w)) / float(w - 1);
        float y = float(i / w) / float(h - 1);
        return texture(uBlendShapeWeightTexture, vec2(x, y));
    }
#endif

    void main()
    {
        vec4 vertex = aPosition;
        vec3 normal = aNormal;
        vec4 tangent = aTangent;

#if (_BLEND_SHAPE_ON == 1)
        {
            vec4 v0 = texture(uBlendShapeWeightTexture, vec2(0, 0));
            int weightTextureWidth = combine_int(v0.xy);
            int weightTextureHeight = combine_int(v0.zw);
            vec4 v1 = sample_weight_vec(1, weightTextureWidth, weightTextureHeight);
            int weightCount = combine_int(v1.xy);
            int vertexCount = combine_int(v1.zw);
            vec4 v2 = sample_weight_vec(2, weightTextureWidth, weightTextureHeight);
            int shapeTextureWidth = combine_int(v2.xy);
            int shapeTextureHeight = combine_int(v2.zw);
            int vertexIndex = int(aVertexIndex);

            const int WeightCountMax = 100;
            for (int i = 0; i < WeightCountMax; ++i)
            {
                if (i >= weightCount)
                {
                    break;
                }

                vec4 vi = sample_weight_vec(3 + i, weightTextureWidth, weightTextureHeight);
                int shapeIndex = combine_int(vi.xy);
                float weight = vi.z;

                int vectorIndex = vertexCount * shapeIndex + vertexIndex;
                float x = float(mod(float(vectorIndex), float(shapeTextureWidth))) / float(shapeTextureWidth - 1);
                float y = float(vectorIndex / shapeTextureWidth) / float(shapeTextureHeight - 1);
                vec4 vertexOffset = texture(uBlendShapeTexture, vec2(x, y));
                vertex.xyz += vertexOffset.xyz * weight;

                vectorIndex = vertexCount * weightCount + vertexCount * shapeIndex + vertexIndex;
                x = float(mod(float(vectorIndex), float(shapeTextureWidth))) / float(shapeTextureWidth - 1);
                y = float(vectorIndex / shapeTextureWidth) / float(shapeTextureHeight - 1);
                vec4 normalOffset = texture(uBlendShapeTexture, vec2(x, y));
                normal.xyz += normalOffset.xyz * weight;

                vectorIndex = vertexCount * weightCount * 2 + vertexCount * shapeIndex + vertexIndex;
                x = float(mod(float(vectorIndex), float(shapeTextureWidth))) / float(shapeTextureWidth - 1);
                y = float(vectorIndex / shapeTextureWidth) / float(shapeTextureHeight - 1);
                vec4 tangentOffset = texture(uBlendShapeTexture, vec2(x, y));
                tangent.xyz += tangentOffset.xyz * weight;
            }
        }
#endif

        mat4 worldMatrix;

#if (_SKIN_ON == 1)
        // skin mesh
        {
            int index_0 = int(aBlendIndex.x);
            int index_1 = int(aBlendIndex.y);
            int index_2 = int(aBlendIndex.z);
            int index_3 = int(aBlendIndex.w);
            float weights_0 = aBlendWeight.x;
            float weights_1 = aBlendWeight.y;
            float weights_2 = aBlendWeight.z;
            float weights_3 = aBlendWeight.w;
            mat4 bone_0 = mat4(uBones[index_0*3], uBones[index_0*3+1], uBones[index_0*3+2], vec4(0.0, 0.0, 0.0, 1.0));
            mat4 bone_1 = mat4(uBones[index_1*3], uBones[index_1*3+1], uBones[index_1*3+2], vec4(0.0, 0.0, 0.0, 1.0));
            mat4 bone_2 = mat4(uBones[index_2*3], uBones[index_2*3+1], uBones[index_2*3+2], vec4(0.0, 0.0, 0.0, 1.0));
            mat4 bone_3 = mat4(uBones[index_3*3], uBones[index_3*3+1], uBones[index_3*3+2], vec4(0.0, 0.0, 0.0, 1.0));
            worldMatrix = bone_0 * weights_0 + bone_1 * weights_1 + bone_2 * weights_2 + bone_3 * weights_3;
        }

        // transpose
        {
            float temp = worldMatrix[0][1];
            worldMatrix[0][1] = worldMatrix[1][0];
            worldMatrix[1][0] = temp;

            temp = worldMatrix[0][2];
            worldMatrix[0][2] = worldMatrix[2][0];
            worldMatrix[2][0] = temp;

            temp = worldMatrix[0][3];
            worldMatrix[0][3] = worldMatrix[3][0];
            worldMatrix[3][0] = temp;

            temp = worldMatrix[1][2];
            worldMatrix[1][2] = worldMatrix[2][1];
            worldMatrix[2][1] = temp;

            temp = worldMatrix[1][3];
            worldMatrix[1][3] = worldMatrix[3][1];
            worldMatrix[3][1] = temp;

            temp = worldMatrix[2][3];
            worldMatrix[2][3] = worldMatrix[3][2];
            worldMatrix[3][2] = temp;
        }
#else
        worldMatrix = uWorldMatrix;
#endif

        gl_Position = uProjectionMatrix * uViewMatrix * worldMatrix * vertex;

#if (_FRAME_ANIM_ON == 1)
		int frame = int(_Time.y * _FrameRate);
		frame = frame - (frame / int(_FrameCount)) * int(_FrameCount);
		int x = frame - (frame / int(_FrameX)) * int(_FrameX);
		int y = frame / int(_FrameX);
		float w = 1.0 / float(_FrameX);
		float h = 1.0 / float(_FrameY);

		vec4 scale_offset;
		scale_offset.x = w;
		scale_offset.y = h;
		scale_offset.z = float(x) * w;
		scale_offset.w = float(y) * h;

		vUV = aTextureCoord * scale_offset.xy + scale_offset.zw;
#else
        vUV = aTextureCoord * _UVScaleOffset.xy + _UVScaleOffset.zw;
#endif

#if (_OFFSET_ANIM_ON == 1)
        vUV += _OffsetSpeed.xy * _Time.y;
#endif

        vec3 posWorld = (worldMatrix * vertex).xyz;
        vec3 normalWorld = normalize((worldMatrix * vec4(normal, 0.0)).xyz);

        vec3 out_pos = posWorld;
        vec3 out_normal = normalWorld;

#if (_NORMALMAP_ON == 1)
        //worldspace
	    vec3 tangentWorld = normalize((worldMatrix * vec4(tangent.xyz, 0.0)).xyz);
        vec3 binormalWorld = normalize(cross(normalWorld, tangentWorld) * tangent.w);

        vTSpace0 = vec4(tangentWorld.x, binormalWorld.x, normalWorld.x, out_pos.x);
        vTSpace1 = vec4(tangentWorld.y, binormalWorld.y, normalWorld.y, out_pos.y);
        vTSpace2 = vec4(tangentWorld.z, binormalWorld.z, normalWorld.z, out_pos.z);
#else
        vPos = out_pos;
        vNormal = out_normal;
#endif

#if (SHADOWMAP == 1)
        vPosLighProj = uLightViewProjectionMatrix * worldMatrix * vertex;
#endif
    }
]]

fs = shaderFeatures .. [[
    precision highp float;

    uniform vec4 uWorldCameraPos;

    uniform float _Cutoff;

    uniform vec4 _Color;

    uniform sampler2D _MainTex;
    uniform sampler2D _NormalMap;
    uniform sampler2D _MetallicRoughnessOcclusionMap;

    uniform float _Metallic;
    uniform float _Roughness;
    uniform float _Occlusion;

    uniform samplerCube _IrradianceMap;
    uniform samplerCube _PrefilterMap;
    uniform sampler2D _BRDF;

    uniform vec4 _LightDir;
	uniform vec4 _LightColor;
    uniform float _LightIntensity;
#if (_LIGHT2_ON == 1)
    uniform vec4 _LightDir2;
    uniform vec4 _LightColor2;
    uniform float _LightIntensity2;
#endif

    uniform sampler2D _EmissiveMap;
    uniform vec4 _EmissiveColor;

    in vec2 vUV;

#if (_NORMALMAP_ON == 1)
    in vec4 vTSpace0;
    in vec4 vTSpace1;
    in vec4 vTSpace2;
#else
    in vec3 vPos;
    in vec3 vNormal;
#endif

#if (SHADOWMAP == 1)
    uniform float _ShadowStrength;
    uniform float _ShadowZBias;
    uniform float _ShadowSlopeBias;
    uniform float _ShadowFilterRadius;
    uniform highp sampler2D _ShadowMap;
    in vec4 vPosLighProj;

    float texture_shadow(vec2 uv)
    {
        if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0)
        {
            return 1.0;
        }
        else
        {
            return texture(_ShadowMap, vec2(uv.x, 1.0 - uv.y)).r;
        }
    }

    float sample_shadow(vec4 posLightProj, vec2 filterRadius, float zBias)
    {
        vec2 uv = posLightProj.xy * 0.5 + 0.5;
        uv.y = 1.0 - uv.y;
        float z = posLightProj.z * 0.5 + 0.5;
        if (z <= 0.0 || z >= 1.0)
        {
            return 0.0;
        }

        float shadow = 0.0;
        for (int i = -1; i <= 1; ++i)
        {
            for (int j = -1; j <= 1; ++j)
            {
                vec2 offset = vec2(float(i), float(j)) * filterRadius;
                float depth = texture_shadow(uv + offset);
                if (z - zBias > depth)
                {
                    shadow += 1.0;
                }
            }
        }
        return shadow / 9.0;
    }
#endif

    out vec4 FragColor;

    // ----------------------------------------------------------------------------
    float DistributionGGX(vec3 N, vec3 H, float roughness)
    {
        const float PI = 3.14159265359;
        float a = roughness * roughness;
        float a2 = a * a;
        float NdotH = max(dot(N, H), 0.0);
        float NdotH2 = NdotH * NdotH;

        float nom = a2;
        float denom = (NdotH2 * (a2 - 1.0) + 1.0);
        denom = PI * denom * denom;

        return nom / denom;
    }
    // ----------------------------------------------------------------------------
    float GeometrySchlickGGX(float NdotV, float roughness)
    {
        float r = (roughness + 1.0);
        float k = (r * r) / 8.0;

        float nom = NdotV;
        float denom = NdotV * (1.0 - k) + k;

        return nom / denom;
    }
    // ----------------------------------------------------------------------------
    float GeometrySmith(vec3 N, vec3 V, vec3 L, float roughness)
    {
        float NdotV = max(dot(N, V), 0.0);
        float NdotL = max(dot(N, L), 0.0);
        float ggx2 = GeometrySchlickGGX(NdotV, roughness);
        float ggx1 = GeometrySchlickGGX(NdotL, roughness);

        return ggx1 * ggx2;
    }
    // ----------------------------------------------------------------------------
    vec3 fresnelSchlick(float cosTheta, vec3 F0)
    {
        return F0 + (1.0 - F0) * pow(1.0 - cosTheta, 5.0);
    }
    // ----------------------------------------------------------------------------
    vec3 fresnelSchlickRoughness(float cosTheta, vec3 F0, float roughness)
    {
        float smoothness = 1.0 - roughness;
        return F0 + (max(vec3(smoothness, smoothness, smoothness), F0) - F0) * pow(1.0 - cosTheta, 5.0);
    }
    // ----------------------------------------------------------------------------

    vec4 frag(vec4 base, float alpha)
    {
        vec2 uv = vUV;
	    //vec4 base = texture(_MainTex, uv);
        
        vec3 albedo = pow(base.rgb, vec3(2.2)) * _Color.rgb;
        //float alpha = base.a * _Color.a;

//#if (_ALPHATEST_ON == 1)
//        if (alpha - _Cutoff < 0.001)
//        {
//            discard;
//        }
//#endif

        vec3 mro = texture(_MetallicRoughnessOcclusionMap, uv).rgb;
        float metallic = mro.r * _Metallic;
        float roughness = mro.g * _Roughness;
        float ao = mro.b * _Occlusion;

#if (_NORMALMAP_ON == 1)
	    vec3 n = texture(_NormalMap, uv).rgb * 2.0 - 1.0;
        n.z = sqrt(1.0 - n.x * n.x - n.y * n.y);
        vec3 normal = normalize(vec3(dot(vTSpace0.xyz, n), dot(vTSpace1.xyz, n), dot(vTSpace2.xyz, n)));
        vec3 pos = vec3(vTSpace0.w, vTSpace1.w, vTSpace2.w);
#else
        vec3 normal = normalize(vNormal);
        vec3 pos = vPos;
#endif

        vec3 viewDir = normalize(uWorldCameraPos.xyz - pos);
        vec3 lightDir = normalize(-_LightDir.xyz);
        vec3 lightColor = _LightColor.rgb * _LightIntensity;

#if (_LIGHT2_ON == 1)
        vec3 lightDir2 = normalize(-_LightDir2.xyz);
        vec3 lightColor2 = _LightColor2.rgb * _LightIntensity2;

        const int LightCount = 2;
        vec3 lightDirs[LightCount];
        vec3 lightColors[LightCount];
        lightDirs[0] = lightDir;
        lightColors[0] = lightColor;
        lightDirs[1] = lightDir2;
        lightColors[1] = lightColor2;
#else
        const int LightCount = 1;
        vec3 lightDirs[LightCount];
        vec3 lightColors[LightCount];
        lightDirs[0] = lightDir;
        lightColors[0] = lightColor;
#endif

        const float PI = 3.14159265359;
        vec3 N = normal;
        vec3 V = viewDir;
        vec3 R = reflect(-V, N);

        vec3 F0 = vec3(0.04, 0.04, 0.04);
        F0 = mix(F0, albedo, metallic);
        vec3 Lo = vec3(0.0, 0.0, 0.0);

        for (int i = 0; i < LightCount; ++i)
        {
            vec3 L = lightDirs[i];
            vec3 H = normalize(V + L);
            vec3 radiance = lightColors[i];

            float NDF = DistributionGGX(N, H, roughness);
            float G = GeometrySmith(N, V, L, roughness);
            vec3 F = fresnelSchlick(max(dot(H, V), 0.0), F0);

            vec3 nominator = NDF * G * F;
            float denominator = 4 * max(dot(N, V), 0.0) * max(dot(N, L), 0.0) + 0.001; // 0.001 to prevent divide by zero.
            vec3 specular = nominator / denominator;

            vec3 kS = F;
            vec3 kD = vec3(1.0, 1.0, 1.0) - kS;
            kD *= 1.0 - metallic;

            float NdotL = max(dot(N, L), 0.0);
            Lo += (kD * albedo / PI + specular) * radiance * NdotL;
        }

        vec3 F = fresnelSchlickRoughness(max(dot(N, V), 0.0), F0, roughness);

        vec3 kS = F;
        vec3 kD = vec3(1.0) - kS;
        kD *= 1.0 - metallic;

        vec3 irradiance = texture(_IrradianceMap, N).rgb;
        vec3 diffuse = irradiance * albedo;

        const float MAX_REFLECTION_LOD = 7.0;
        vec3 prefilteredColor = textureLod(_PrefilterMap, R, roughness * MAX_REFLECTION_LOD).rgb;
        vec2 brdf = texture(_BRDF, vec2(max(dot(N, V), 0.0), roughness)).rg;
        vec3 specular = prefilteredColor * (F * brdf.x + brdf.y);

        vec3 ambient = (kD * diffuse + specular) * ao;
        vec3 color = ambient + Lo;

        vec3 emissive = pow(texture(_EmissiveMap, uv).rgb, vec3(2.2)) * _EmissiveColor.rgb;
        color += emissive;

        // HDR tonemapping
        color = color / (color + vec3(1.0));
        // gamma correct
        color = pow(color, vec3(1.0 / 2.2));

        vec4 c = vec4(color, alpha);

        return c;
    }
]]

fs_clip_t = fs .. [[
    void main()
    {
        vec2 uv = vUV;
	    vec4 base = texture(_MainTex, uv);
        
        float alpha = base.a * _Color.a;

        if (alpha - _Cutoff < 0.0)
        {
            discard;
        }

        vec4 c = frag(base, alpha);
        c.a = 0.0;

        FragColor = c;
    }
]]

fs_clip_o = fs .. [[
    void main()
    {
        vec2 uv = vUV;
	    vec4 base = texture(_MainTex, uv);
        
        float alpha = base.a * _Color.a;

        if (_Cutoff - alpha < 0.0)
        {
            discard;
        }

        vec4 c = frag(base, alpha);

        FragColor = c;
    }
]]

--[[
    Cull
	    Back | Front | Off
    ZTest
	    Less | Greater | LEqual | GEqual | Equal | NotEqual | Always
    ZWrite
	    On | Off
    Blend
	    Off / SrcBlendMode DstBlendMode
	    One Zero SrcColor SrcAlpha DstColor DstAlpha OneMinusSrcColor OneMinusSrcAlpha OneMinusDstColor OneMinusDstAlpha
    Queue
        Background | Geometry | AlphaTest | Transparent | Overlay
    Version
        100 | 300 | 310 | 320
]]

local rs_clip_t = {
    Cull = Off,
    ZTest = LEqual,
    ZWrite = On,
    Blend = Off,
    SrcBlendMode = SrcAlpha,
    DstBlendMode = OneMinusSrcAlpha,
    Queue = Transparent,
    Version = 300,
}

local rs_clip_o = {
    Cull = Off,
    ZTest = LEqual,
    ZWrite = Off,
    Blend = On,
    SrcBlendMode = SrcAlpha,
    DstBlendMode = OneMinusSrcAlpha,
    Queue = Transparent,
    Version = 300,
}

local pass_clip_t = {
    vs = vs,
    fs = fs_clip_t,
    rs = rs_clip_t,
}

local pass_clip_o = {
    vs = vs,
    fs = fs_clip_o,
    rs = rs_clip_o,
}

-- return pass array
return {
    pass_clip_t,
    pass_clip_o
}