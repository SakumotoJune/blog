vs = [[
    uniform mat4 uViewProjectionMatrix;
    uniform vec4 uWorldCameraPos;
    uniform float _Rotation;

    attribute vec4 aPosition;

    varying vec3 vUV;

    vec3 RotateAroundYInDegrees(vec3 vertex, float degrees)
    {
        float alpha = degrees * 3.14159 / 180.0;
        float sina = sin(alpha);
        float cosa = cos(alpha);
        mat2 m = mat2(vec2(cosa, -sina), vec2(sina, cosa));
        return vec3(m * vertex.xz, vertex.y).xzy;
    }

    void main()
    {
        vec3 rotated = RotateAroundYInDegrees(aPosition.xyz, -_Rotation);
        mat4 model = mat4(vec4(1.0, 0.0, 0.0, 0.0), vec4(0.0, 1.0, 0.0, 0.0), vec4(0.0, 0.0, 1.0, 0.0), vec4(uWorldCameraPos.xyz, 1.0));
        vec4 pos = uViewProjectionMatrix * model * vec4(rotated, 1.0);
        gl_Position = pos.xyww;
        vUV = aPosition.xyz;
        vUV.y = -vUV.y;
    }
]]

fs = [[
#ifndef _SRGB_ON
#define _SRGB_ON 0
#endif

    precision highp float;

    uniform samplerCube _Cubemap;
    uniform vec4 _Tint;
    uniform float _Exposure;

    varying vec3 vUV;

    void main()
    {
        vec3 c = textureCube(_Cubemap, vUV).rgb;

#if (_SRGB_ON == 1)
        c = pow(c, vec3(2.2));
#endif

        c = c * _Tint.rgb * 2.0;
        c *= _Exposure;

        gl_FragColor = vec4(c, 1.0);
    }
]]

--[[
    Cull
	    Back | Front | Off
    ZTest
	    Less | Greater | LEqual | GEqual | Equal | NotEqual | Always
    ZWrite
	    On | Off
    Blend
	    Off / SrcBlendMode DstBlendMode
	    One Zero SrcColor SrcAlpha DstColor DstAlpha OneMinusSrcColor OneMinusSrcAlpha OneMinusDstColor OneMinusDstAlpha
]]

local rs = {
    Cull = Front,
    ZTest = LEqual,
    ZWrite = Off,
    Blend = Off,
    SrcBlendMode = SrcAlpha,
    DstBlendMode = OneMinusSrcAlpha,
    Queue = Background,
}

local pass = {
    vs = vs,
    fs = fs,
    rs = rs,
}

-- return pass array
return {
    pass
}
