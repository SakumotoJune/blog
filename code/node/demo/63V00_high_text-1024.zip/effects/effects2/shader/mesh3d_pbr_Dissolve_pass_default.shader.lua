require("mesh3d_pbr_Dissolve_default_vs")
require("mesh3d_pbr_Dissolve_default_fs")



fs = fs .. [[
    void main()
    {
        vec4 c = pbr();

        /* =======================Dissolve==========================*/
        vec2 uv = vUV;

        //通过simplex 噪声生成噪声纹理
        float val = noise_sum_simplex(uv*_NoiseDenseness);
        val = val * _NoiseContrast + 0.45; //val * A + B A变越大越浓 B越大越淡

        //溶解
        vec4 noise_col=vec4(val, val, val, 1);
        float timing_start = _TimingStart;
        float t=_TimingStart;
        timing_start = timing_start -_Time.y;
        
        if(timing_start<0.001){
            float strength = (_Time.y-t) /(_Times ) + _Strength; //时间问题
            float s = noise_col.r - strength;
            if(s < 0.001)
            {
               discard;         // 如果小于阈值，就抛弃该片断
            } 
            (s>_Edge) ? (c=c):(c = _EdgeColor);

        }


        gl_FragColor = c;
    }
]]

--[[
    Cull
	    Back | Front | Off
    ZTest
	    Less | Greater | LEqual | GEqual | Equal | NotEqual | Always
    ZWrite
	    On | Off
    Blend
	    Off / SrcBlendMode DstBlendMode
	    One Zero SrcColor SrcAlpha DstColor DstAlpha OneMinusSrcColor OneMinusSrcAlpha OneMinusDstColor OneMinusDstAlpha
]]

local rs = {
    Cull = Back,
    ZTest = LEqual,
    ZWrite = On,
    Blend = Off,
    SrcBlendMode = SrcAlpha,
    DstBlendMode = OneMinusSrcAlpha,
    Queue = Geometry,
}

local pass = {
    vs = vs,
    fs = fs,
    rs = rs,
}

-- return pass array
return {
    pass
}



