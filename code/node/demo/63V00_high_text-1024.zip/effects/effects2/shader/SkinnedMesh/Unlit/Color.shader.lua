local vs = [[
#ifndef OF_WASM
    #define OF_WASM 0
#endif

#if (OF_WASM == 1)
    uniform vec4 uBones[90];
#else
    uniform vec4 uBones[210];
#endif

    uniform mat4 uViewProjectionMatrix;

    attribute vec3 aPosition;
    attribute vec4 aBlendWeight;
    attribute vec4 aBlendIndex;

    void main()
    {
        mat4 worldMatrix;
        
        // skin mesh
        int index_0 = int(aBlendIndex.x);
        int index_1 = int(aBlendIndex.y);
        int index_2 = int(aBlendIndex.z);
        int index_3 = int(aBlendIndex.w);
        float weights_0 = aBlendWeight.x;
        float weights_1 = aBlendWeight.y;
        float weights_2 = aBlendWeight.z;
        float weights_3 = aBlendWeight.w;
        mat4 bone_0 = mat4(uBones[index_0*3], uBones[index_0*3+1], uBones[index_0*3+2], vec4(0, 0, 0, 1));
        mat4 bone_1 = mat4(uBones[index_1*3], uBones[index_1*3+1], uBones[index_1*3+2], vec4(0, 0, 0, 1));
        mat4 bone_2 = mat4(uBones[index_2*3], uBones[index_2*3+1], uBones[index_2*3+2], vec4(0, 0, 0, 1));
        mat4 bone_3 = mat4(uBones[index_3*3], uBones[index_3*3+1], uBones[index_3*3+2], vec4(0, 0, 0, 1));
        worldMatrix = bone_0 * weights_0 + bone_1 * weights_1 + bone_2 * weights_2 + bone_3 * weights_3;

        gl_Position = uViewProjectionMatrix * (vec4(aPosition, 1.0) * worldMatrix);
    }
]]

local fs = [[
    precision highp float;

    uniform vec4 _Color;

    void main()
    {
        gl_FragColor = _Color;
    }
]]

--[[
    Cull
	    Back | Front | Off
    ZTest
	    Less | Greater | LEqual | GEqual | Equal | NotEqual | Always
    ZWrite
	    On | Off
    Blend
	    Off / SrcBlendMode DstBlendMode
	    One Zero SrcColor SrcAlpha DstColor DstAlpha OneMinusSrcColor OneMinusSrcAlpha OneMinusDstColor OneMinusDstAlpha
]]

local rs = {
    Cull = Back,
    ZTest = LEqual,
    ZWrite = On,
    Blend = Off,
    SrcBlendMode = SrcAlpha,
    DstBlendMode = OneMinusSrcAlpha,
    Queue = Geometry,
}

local pass = {
    vs = vs,
    fs = fs,
    rs = rs,
}

-- return pass array
return {
    pass
}
