local vs_shade = [[
#ifndef OF_WASM
    #define OF_WASM 0
#endif

#if (OF_WASM == 1)
    uniform vec4 uBones[90];
#else
    uniform vec4 uBones[210];
#endif

    uniform mat4 uViewProjectionMatrix;
    uniform mat4 uViewMatrix;

    attribute vec3 aPosition;
    attribute vec2 aTextureCoord;
    attribute vec3 aNormal;
    attribute vec4 aBlendWeight;
    attribute vec4 aBlendIndex;

    varying vec2 vUV;
    varying vec3 vNormal;

    void main()
    {
        mat4 worldMatrix;
        
        // skin mesh
        int index_0 = int(aBlendIndex.x);
        int index_1 = int(aBlendIndex.y);
        int index_2 = int(aBlendIndex.z);
        int index_3 = int(aBlendIndex.w);
        float weights_0 = aBlendWeight.x;
        float weights_1 = aBlendWeight.y;
        float weights_2 = aBlendWeight.z;
        float weights_3 = aBlendWeight.w;
        mat4 bone_0 = mat4(uBones[index_0*3], uBones[index_0*3+1], uBones[index_0*3+2], vec4(0, 0, 0, 1));
        mat4 bone_1 = mat4(uBones[index_1*3], uBones[index_1*3+1], uBones[index_1*3+2], vec4(0, 0, 0, 1));
        mat4 bone_2 = mat4(uBones[index_2*3], uBones[index_2*3+1], uBones[index_2*3+2], vec4(0, 0, 0, 1));
        mat4 bone_3 = mat4(uBones[index_3*3], uBones[index_3*3+1], uBones[index_3*3+2], vec4(0, 0, 0, 1));
        worldMatrix = bone_0 * weights_0 + bone_1 * weights_1 + bone_2 * weights_2 + bone_3 * weights_3;

        gl_Position = uViewProjectionMatrix * (vec4(aPosition, 1.0) * worldMatrix);
        vUV = aTextureCoord;
        vNormal = (uViewMatrix * (vec4(aNormal, 0.0) * worldMatrix)).xyz;
    }
]]

local fs_shade = [[
    precision highp float;

    uniform vec4 _Color;
    uniform sampler2D _MainTex;
    uniform samplerCube  _ToonShade;

    varying vec2 vUV;
    varying vec3 vNormal;

    void main()
    {
        vec4 c = texture2D(_MainTex, vUV) * _Color;
        vec4 cube = textureCube(_ToonShade, vNormal);
        c.rgb = c.rgb * cube.rgb * 2.0;
        gl_FragColor = c;
    }
]]

local vs_outline = [[
#ifndef OF_WASM
    #define OF_WASM 0
#endif

#if (OF_WASM == 1)
    uniform vec4 uBones[90];
#else
    uniform vec4 uBones[210];
#endif

    uniform mat4 uViewProjectionMatrix;
    uniform float _Outline;

    attribute vec3 aPosition;
    attribute vec4 aBlendWeight;
    attribute vec4 aBlendIndex;
    attribute vec3 aNormal;

    void main()
    {
        mat4 worldMatrix;
        
        // skin mesh
        int index_0 = int(aBlendIndex.x);
        int index_1 = int(aBlendIndex.y);
        int index_2 = int(aBlendIndex.z);
        int index_3 = int(aBlendIndex.w);
        float weights_0 = aBlendWeight.x;
        float weights_1 = aBlendWeight.y;
        float weights_2 = aBlendWeight.z;
        float weights_3 = aBlendWeight.w;
        mat4 bone_0 = mat4(uBones[index_0*3], uBones[index_0*3+1], uBones[index_0*3+2], vec4(0, 0, 0, 1));
        mat4 bone_1 = mat4(uBones[index_1*3], uBones[index_1*3+1], uBones[index_1*3+2], vec4(0, 0, 0, 1));
        mat4 bone_2 = mat4(uBones[index_2*3], uBones[index_2*3+1], uBones[index_2*3+2], vec4(0, 0, 0, 1));
        mat4 bone_3 = mat4(uBones[index_3*3], uBones[index_3*3+1], uBones[index_3*3+2], vec4(0, 0, 0, 1));
        worldMatrix = bone_0 * weights_0 + bone_1 * weights_1 + bone_2 * weights_2 + bone_3 * weights_3;

        gl_Position = uViewProjectionMatrix * (vec4(aPosition + aNormal * _Outline, 1.0) * worldMatrix);
    }
]]

local fs_outline = [[
    precision highp float;

    uniform vec4 _OutlineColor;

    void main()
    {
        gl_FragColor = _OutlineColor;
    }
]]

--[[
    Cull
	    Back | Front | Off
    ZTest
	    Less | Greater | LEqual | GEqual | Equal | NotEqual | Always
    ZWrite
	    On | Off
    Blend
	    Off / SrcBlendMode DstBlendMode
	    One Zero SrcColor SrcAlpha DstColor DstAlpha OneMinusSrcColor OneMinusSrcAlpha OneMinusDstColor OneMinusDstAlpha
]]

local rs_shade = {
    Cull = Back,
    ZTest = LEqual,
    ZWrite = On,
    Blend = Off,
    SrcBlendMode = SrcAlpha,
    DstBlendMode = OneMinusSrcAlpha,
    Queue = Geometry,
}

local rs_outline = {
    Cull = Front,
    ZTest = LEqual,
    ZWrite = On,
    Blend = Off,
    SrcBlendMode = SrcAlpha,
    DstBlendMode = OneMinusSrcAlpha,
    Queue = Geometry,
}

local pass_shade = {
    vs = vs_shade,
    fs = fs_shade,
    rs = rs_shade,
}

local pass_outline = {
    vs = vs_outline,
    fs = fs_outline,
    rs = rs_outline,
}

-- return pass array
return {
    pass_shade,
    pass_outline,
}
