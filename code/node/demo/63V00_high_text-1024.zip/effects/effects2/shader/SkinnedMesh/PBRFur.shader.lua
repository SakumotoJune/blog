require("mesh3d_skin_vs")
require("mesh3d_pbr_fs")

--[[
    Cull
	    Back | Front | Off
    ZTest
	    Less | Greater | LEqual | GEqual | Equal | NotEqual | Always
    ZWrite
	    On | Off
    Blend
	    Off / SrcBlendMode DstBlendMode
	    One Zero SrcColor SrcAlpha DstColor DstAlpha OneMinusSrcColor OneMinusSrcAlpha OneMinusDstColor OneMinusDstAlpha
]]

local rs = {
    Cull = Off,
    ZTest = LEqual,
    ZWrite = On,
    Blend = On,
    SrcBlendMode = SrcAlpha,
    DstBlendMode = OneMinusSrcAlpha,
    Queue = AlphaTest,
}

passes = { }

for i = 1, 20 do
    local pass = { }
    local layer = (i - 1) / 20.0

    pass.vs = vs .. string.format([[
        uniform float _FurLength;
        uniform vec4 _FurTexUVScaleOffset;
        varying vec2 vFurUV;
        void main()
        { 
            vec4 vertex = aPosition;
            vertex.xyz = vertex.xyz + aNormal * _FurLength * %f;
            vert(vertex);

            vFurUV = aTextureCoord * _FurTexUVScaleOffset.xy + _FurTexUVScaleOffset.zw;
        }
    ]], layer)

    pass.fs = fs .. string.format([[
        uniform float _CutAlpha;
        uniform sampler2D _FurNoise;
        uniform sampler2D _FurMask;
        uniform vec4 _FurParam;
        varying vec2 vFurUV;
        void main()
        {
            vec4 base = texture2D(_MainTex, vUV);
            vec4 c = base * _Color;
				
			vec3 n = texture2D(_Normal, vUV).rgb * 2.0 - 1.0;
			vec3 posView = vec3(vTSpace0.w, vTSpace1.w, vTSpace2.w);
			vec3 normal = normalize(vec3(dot(vTSpace0.xyz, n), dot(vTSpace1.xyz, n), dot(vTSpace2.xyz, n)));
			vec3 viewDir = normalize(-posView);
       
            float layer = %f;
            float fur = 1.0 - layer * layer;
            fur += clamp(dot(viewDir, normal), 0.0, 1.0) -_FurParam.x;
            if (layer > 0.0)
            {
                fur *= texture2D(_FurNoise, vFurUV).a * texture2D(_FurMask, vFurUV).r * _FurParam.z;
            }

            float fake = mix(_FurParam.y, 1.0,  layer);
            
            c.rgb *= fake;
            c.a = fur;

            if (c.a - _CutAlpha < 0.001)
            {
                discard;
            }
            vec4 dstpbr = GI(base, c, normal, viewDir);
            gl_FragColor = dstpbr;
        }
    ]], layer)

    pass.rs = rs

    passes[i] = pass
end

-- return pass array
return passes
