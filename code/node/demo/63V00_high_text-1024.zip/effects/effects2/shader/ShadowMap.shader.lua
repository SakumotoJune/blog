local vs = [[
#ifndef _SKIN_ON
#define _SKIN_ON 0
#endif
#ifndef _BLEND_SHAPE_ON
#define _BLEND_SHAPE_ON 0
#endif
#ifndef OF_WASM
    #define OF_WASM 0
#endif

#if (_SKIN_ON == 1)
#if (OF_WASM == 1)
    uniform vec4 uBones[90];
#else
    uniform vec4 uBones[210];
#endif
#endif

    uniform mat4 uWorldMatrix;
    uniform mat4 uViewMatrix;
    uniform mat4 uProjectionMatrix;

    attribute vec4 aPosition;
    attribute vec2 aTextureCoord;
    attribute vec3 aNormal;
    attribute vec4 aTangent;

#if (_SKIN_ON == 1)
    attribute vec4 aBlendWeight;
    attribute vec4 aBlendIndex;
#endif

    varying vec2 vUV;

#if (_BLEND_SHAPE_ON == 1)
    attribute float aVertexIndex;
    uniform sampler2D uBlendShapeTexture;
    uniform sampler2D uBlendShapeWeightTexture;

    int combine_int(vec2 v)
    {
        return int(v.x) * 256 + int(v.y);
    }

    vec4 sample_weight_vec(int i, int w, int h)
    {
        float x = mod(float(i), float(w)) / float(w - 1);
        float y = float(i / w) / float(h - 1);
        return texture2D(uBlendShapeWeightTexture, vec2(x, y));
    }
#endif

    void main()
    {
        vec4 vertex = aPosition;
        vec3 normal = aNormal;
        vec4 tangent = aTangent;

#if (_BLEND_SHAPE_ON == 1)
        {
            vec4 v0 = texture2D(uBlendShapeWeightTexture, vec2(0, 0));
            int weightTextureWidth = combine_int(v0.xy);
            int weightTextureHeight = combine_int(v0.zw);
            vec4 v1 = sample_weight_vec(1, weightTextureWidth, weightTextureHeight);
            int weightCount = combine_int(v1.xy);
            int vertexCount = combine_int(v1.zw);
            vec4 v2 = sample_weight_vec(2, weightTextureWidth, weightTextureHeight);
            int shapeTextureWidth = combine_int(v2.xy);
            int shapeTextureHeight = combine_int(v2.zw);
            int vertexIndex = int(aVertexIndex);

            const int WeightCountMax = 100;
            for (int i = 0; i < WeightCountMax; ++i)
            {
                if (i >= weightCount)
                {
                    break;
                }

                vec4 vi = sample_weight_vec(3 + i, weightTextureWidth, weightTextureHeight);
                int shapeIndex = combine_int(vi.xy);
                float weight = vi.z;

                int vectorIndex = vertexCount * shapeIndex + vertexIndex;
                float x = float(mod(float(vectorIndex), float(shapeTextureWidth))) / float(shapeTextureWidth - 1);
                float y = float(vectorIndex / shapeTextureWidth) / float(shapeTextureHeight - 1);
                vec4 vertexOffset = texture2D(uBlendShapeTexture, vec2(x, y));
                vertex.xyz += vertexOffset.xyz * weight;
            }
        }
#endif

        mat4 worldMatrix;
        
#if (_SKIN_ON == 1)
        // skin mesh
        {
            int index_0 = int(aBlendIndex.x);
            int index_1 = int(aBlendIndex.y);
            int index_2 = int(aBlendIndex.z);
            int index_3 = int(aBlendIndex.w);
            float weights_0 = aBlendWeight.x;
            float weights_1 = aBlendWeight.y;
            float weights_2 = aBlendWeight.z;
            float weights_3 = aBlendWeight.w;
            mat4 bone_0 = mat4(uBones[index_0*3], uBones[index_0*3+1], uBones[index_0*3+2], vec4(0.0, 0.0, 0.0, 1.0));
            mat4 bone_1 = mat4(uBones[index_1*3], uBones[index_1*3+1], uBones[index_1*3+2], vec4(0.0, 0.0, 0.0, 1.0));
            mat4 bone_2 = mat4(uBones[index_2*3], uBones[index_2*3+1], uBones[index_2*3+2], vec4(0.0, 0.0, 0.0, 1.0));
            mat4 bone_3 = mat4(uBones[index_3*3], uBones[index_3*3+1], uBones[index_3*3+2], vec4(0.0, 0.0, 0.0, 1.0));
            worldMatrix = bone_0 * weights_0 + bone_1 * weights_1 + bone_2 * weights_2 + bone_3 * weights_3;
        }

        // transpose
        {
            float temp = worldMatrix[0][1];
            worldMatrix[0][1] = worldMatrix[1][0];
            worldMatrix[1][0] = temp;

            temp = worldMatrix[0][2];
            worldMatrix[0][2] = worldMatrix[2][0];
            worldMatrix[2][0] = temp;

            temp = worldMatrix[0][3];
            worldMatrix[0][3] = worldMatrix[3][0];
            worldMatrix[3][0] = temp;

            temp = worldMatrix[1][2];
            worldMatrix[1][2] = worldMatrix[2][1];
            worldMatrix[2][1] = temp;

            temp = worldMatrix[1][3];
            worldMatrix[1][3] = worldMatrix[3][1];
            worldMatrix[3][1] = temp;

            temp = worldMatrix[2][3];
            worldMatrix[2][3] = worldMatrix[3][2];
            worldMatrix[3][2] = temp;
        }
#else
        worldMatrix = uWorldMatrix;
#endif
        
        gl_Position = uProjectionMatrix * uViewMatrix * worldMatrix * vertex;
        vUV = aTextureCoord;
    }
]]

local fs = [[
#ifndef _ALPHATEST_ON
#define _ALPHATEST_ON 0
#endif

    precision highp float;
    uniform sampler2D _MainTex;
    uniform vec4 _Color;
    varying vec2 vUV;

#if (_ALPHATEST_ON == 1)
    uniform float _Cutoff;
#endif

    void main()
    {
#if (_ALPHATEST_ON == 1)
	    vec4 base = texture2D(_MainTex, vUV);
        vec4 c = base * _Color;
        if (c.a - _Cutoff < 0.001)
        {
            discard;
        }
#endif
    }
]]

--[[
    Cull
	    Back | Front | Off
    ZTest
	    Less | Greater | LEqual | GEqual | Equal | NotEqual | Always
    ZWrite
	    On | Off
    Blend
	    Off / SrcBlendMode DstBlendMode
	    One Zero SrcColor SrcAlpha DstColor DstAlpha OneMinusSrcColor OneMinusSrcAlpha OneMinusDstColor OneMinusDstAlpha
]]

local rs = {
    Cull = Off,
    ZTest = LEqual,
    ZWrite = On,
    Blend = Off,
    SrcBlendMode = SrcAlpha,
    DstBlendMode = OneMinusSrcAlpha,
    Queue = Geometry,
}

local pass = {
    vs = vs,
    fs = fs,
    rs = rs,
}

-- return pass array
return {
    pass
}
