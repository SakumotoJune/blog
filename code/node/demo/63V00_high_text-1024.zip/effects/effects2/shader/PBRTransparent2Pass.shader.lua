local shaderFeatures = [[
#ifndef _SRGB_ON
#define _SRGB_ON 0
#endif
#ifndef _ALPHATEST_ON
#define _ALPHATEST_ON 0
#endif
#ifndef _LIGHT2_ON
#define _LIGHT2_ON 0
#endif
#ifndef _FRAME_ANIM_ON
#define _FRAME_ANIM_ON 0
#endif
#ifndef _OFFSET_ANIM_ON
#define _OFFSET_ANIM_ON 0
#endif
#ifndef _VIEW_SPACE_LIGHTING_ON
#define _VIEW_SPACE_LIGHTING_ON 0
#endif
#ifndef _NORMALMAP_ON
#define _NORMALMAP_ON 0
#endif
#ifndef _ALPHABLEND_ON
#define _ALPHABLEND_ON 0
#endif
#ifndef _ALPHABLEND_ADD_ON
#define _ALPHABLEND_ADD_ON 0
#endif
#ifndef _CULLOFF_ON
#define _CULLOFF_ON 0
#endif
#ifndef _SKIN_ON
#define _SKIN_ON 0
#endif
#ifndef _HAIR_ANISO_ON
#define _HAIR_ANISO_ON 0
#endif
#ifndef OF_WASM
#define OF_WASM 0
#endif
]]

vs = shaderFeatures .. [[
#if (_SKIN_ON == 1)
#if (OF_WASM == 1)
    uniform vec4 uBones[90];
#else
    uniform vec4 uBones[210];
#endif
#endif

    uniform mat4 uWorldMatrix;
    uniform mat4 uViewMatrix;
    uniform mat4 uProjectionMatrix;

    uniform vec4 _Time;

#if (_FRAME_ANIM_ON == 1)
    uniform float _FrameCount;
    uniform float _FrameX;
    uniform float _FrameY;
    uniform float _FrameRate;
#endif

#if (_OFFSET_ANIM_ON == 1)
    uniform vec4 _OffsetSpeed;
#endif

    attribute vec4 aPosition;
    attribute vec2 aTextureCoord;
    attribute vec3 aNormal;
    attribute vec4 aTangent;

#if (_SKIN_ON == 1)
    attribute vec4 aBlendWeight;
    attribute vec4 aBlendIndex;
#endif

    varying vec2 vUV;

#if (_NORMALMAP_ON == 1)
    varying vec4 vTSpace0;
    varying vec4 vTSpace1;
    varying vec4 vTSpace2;
#else
    varying vec3 vPos;
    varying vec3 vNormal;
#endif

    void main()
    {
        mat4 worldMatrix;
        
#if (_SKIN_ON == 1)
        // skin mesh
        int index_0 = int(aBlendIndex.x);
        int index_1 = int(aBlendIndex.y);
        int index_2 = int(aBlendIndex.z);
        int index_3 = int(aBlendIndex.w);
        float weights_0 = aBlendWeight.x;
        float weights_1 = aBlendWeight.y;
        float weights_2 = aBlendWeight.z;
        float weights_3 = aBlendWeight.w;
        mat4 bone_0 = mat4(uBones[index_0*3], uBones[index_0*3+1], uBones[index_0*3+2], vec4(0.0, 0.0, 0.0, 1.0));
        mat4 bone_1 = mat4(uBones[index_1*3], uBones[index_1*3+1], uBones[index_1*3+2], vec4(0.0, 0.0, 0.0, 1.0));
        mat4 bone_2 = mat4(uBones[index_2*3], uBones[index_2*3+1], uBones[index_2*3+2], vec4(0.0, 0.0, 0.0, 1.0));
        mat4 bone_3 = mat4(uBones[index_3*3], uBones[index_3*3+1], uBones[index_3*3+2], vec4(0.0, 0.0, 0.0, 1.0));
        worldMatrix = bone_0 * weights_0 + bone_1 * weights_1 + bone_2 * weights_2 + bone_3 * weights_3;

        // transpose
        {
            float temp = worldMatrix[0][1];
            worldMatrix[0][1] = worldMatrix[1][0];
            worldMatrix[1][0] = temp;

            temp = worldMatrix[0][2];
            worldMatrix[0][2] = worldMatrix[2][0];
            worldMatrix[2][0] = temp;

            temp = worldMatrix[0][3];
            worldMatrix[0][3] = worldMatrix[3][0];
            worldMatrix[3][0] = temp;

            temp = worldMatrix[1][2];
            worldMatrix[1][2] = worldMatrix[2][1];
            worldMatrix[2][1] = temp;

            temp = worldMatrix[1][3];
            worldMatrix[1][3] = worldMatrix[3][1];
            worldMatrix[3][1] = temp;

            temp = worldMatrix[2][3];
            worldMatrix[2][3] = worldMatrix[3][2];
            worldMatrix[3][2] = temp;
        }
#else
        worldMatrix = uWorldMatrix;
#endif
        
        gl_Position = uProjectionMatrix * uViewMatrix * worldMatrix * aPosition;

#if (_FRAME_ANIM_ON == 1)
		int frame = int(_Time.y * _FrameRate);
		frame = frame - (frame / int(_FrameCount)) * int(_FrameCount);
		int x = frame - (frame / int(_FrameX)) * int(_FrameX);
		int y = frame / int(_FrameX);
		float w = 1.0 / float(_FrameX);
		float h = 1.0 / float(_FrameY);

		vec4 scale_offset;
		scale_offset.x = w;
		scale_offset.y = h;
		scale_offset.z = float(x) * w;
		scale_offset.w = float(y) * h;

		vUV = aTextureCoord * scale_offset.xy + scale_offset.zw;
#else
        vUV = aTextureCoord;
#endif

#if (_OFFSET_ANIM_ON == 1)
        vUV += _OffsetSpeed.xy * _Time.y;
#endif

#if (_VIEW_SPACE_LIGHTING_ON == 1)
        mat4 mat = uViewMatrix * worldMatrix;
#else
        mat4 mat = worldMatrix;
#endif

        vec3 pos = (mat * aPosition).xyz;
        vec3 normal = normalize((mat * vec4(aNormal, 0.0)).xyz);

#if (_NORMALMAP_ON == 1)
	    vec3 tangent = normalize((mat * vec4(aTangent.xyz, 0.0)).xyz);
	    vec3 binormal = normalize(cross(normal, tangent) * aTangent.w);

	    vTSpace0 = vec4(tangent.x, binormal.x, normal.x, pos.x);
	    vTSpace1 = vec4(tangent.y, binormal.y, normal.y, pos.y);
	    vTSpace2 = vec4(tangent.z, binormal.z, normal.z, pos.z);
#else
        vPos = pos;
        vNormal = normal;
#endif
    }
]]

fs = shaderFeatures .. [[
    precision highp float;

    uniform vec4 uWorldCameraPos;
    uniform sampler2D _MainTex;
    uniform sampler2D _NormalMap;
    uniform sampler2D _SpecMap;
    uniform sampler2D _EmissiveMap;
    uniform samplerCube _EnvMap;

    uniform float _Cutoff;

    uniform vec4 _Color;
    uniform vec4 _SpecColor;
    uniform vec4 _EmissiveColor;
    uniform vec4 _LightDir;
    uniform vec4 _LightColor;
    uniform vec4 _AmbientColor;
    uniform vec4 _EnvColor;
    uniform float _Smoothness;

#if (_LIGHT2_ON == 1)
    uniform vec4 _LightDir2;
    uniform vec4 _LightColor2;
#endif

    varying vec2 vUV;

#if (_NORMALMAP_ON == 1)
    varying vec4 vTSpace0;
    varying vec4 vTSpace1;
    varying vec4 vTSpace2;
#else
    varying vec3 vPos;
    varying vec3 vNormal;
#endif

#if (_HAIR_ANISO_ON == 1)
    uniform sampler2D _AnisoMap;
    uniform float _PrimaryShift;
    uniform float _SecondaryShift;
    uniform float _AnisoSpec;
    uniform vec4 _AnisoSpecColor;
    uniform vec4 _AnisoSpecColor2;
    uniform float _AnisoSpecMultiplier;
    uniform float _AnisoSpecMultiplier2;

    float StrandSpecular(vec3 T, vec3 V, vec3 L, float exponent)
    {
        vec3 H = normalize(L + V);
        float dotTH = dot(T, H);
        float sinTH = sqrt(1.0 - dotTH * dotTH);
        float dirAtten = smoothstep(-1.0, 0.0, dotTH);
        return dirAtten * pow(sinTH, exponent);
    }

    vec3 ShiftTangent(vec3 T, vec3 N, float shift)
    {
        return normalize(T + shift * N);
    }
#endif

    vec2 pow4(vec2 x) { return x * x * x * x; }

    vec4 frag(vec4 base, vec4 c)
    {
	    vec2 uv = vUV;

#if (_NORMALMAP_ON == 1)
	    vec3 n = texture2D(_NormalMap, uv).rgb * 2.0 - 1.0;
        n.z = sqrt(1.0 - n.x * n.x - n.y * n.y);
	    vec3 normal = normalize(vec3(dot(vTSpace0.xyz, n), dot(vTSpace1.xyz, n), dot(vTSpace2.xyz, n)));
        vec3 pos = vec3(vTSpace0.w, vTSpace1.w, vTSpace2.w);
#else
        vec3 normal = normalize(vNormal);
        vec3 pos = vPos;
#endif

#if (_VIEW_SPACE_LIGHTING_ON == 1)
        vec3 viewDir = normalize(-pos);
#else
        vec3 viewDir = normalize(uWorldCameraPos.xyz - pos);
#endif

	    vec3 lightDir = normalize(-_LightDir.xyz);
	    vec3 lightColor = _LightColor.rgb;

	    float nl = max(dot(normal, lightDir), 0.0);
	    vec3 h = normalize(lightDir + viewDir);
	    float nh = max(dot(normal, h), 0.0);
	    float nv = max(dot(normal, viewDir), 0.0);
	    vec3 ref = reflect(viewDir, normal);

        vec4 specMap = texture2D(_SpecMap, uv);
        vec3 specColor = _SpecColor.rgb * specMap.rgb;
	    float smoothness = _Smoothness * specMap.a;
        float roughness = 1.0 - smoothness;
	    float reflectivity = max(max(specColor.r, specColor.g), specColor.b);

	    vec2 rlp4 = pow4(vec2(dot(ref, lightDir), 1.0 - nv));
	    float fresnel = rlp4.y;
	    float grazing = clamp(smoothness + reflectivity, 0.0, 1.0);

	    float lh = max(dot(lightDir, h), 0.0);
	    float roughness2 = roughness * roughness;
	    float a = roughness2;
	    float a2 = a * a;
	    float d = nh * nh * (a2 - 1.0) + 1.00001;
	    float spec = a2 / (max(0.1, lh * lh) * (roughness2 + 0.5) * (d * d) * 4.0);
	    spec = max(spec - 1e-4, 0.0);
	
	    ref.y = -ref.y;
	    vec3 env = textureCube(_EnvMap, -ref).rgb;
        vec3 emi = texture2D(_EmissiveMap, uv).rgb;

#if (_SRGB_ON == 1)
        env = pow(env, vec3(2.2));
        emi = pow(emi, vec3(2.2));
#endif

	    vec3 diffuse = c.rgb * _AmbientColor.rgb + c.rgb * nl * lightColor;
	    vec3 specular = spec * specColor * lightColor;
	    vec3 gi = env * _EnvColor.rgb * 2.0 * mix(specColor, vec3(1.0) * grazing, fresnel);
        vec3 emissive = emi * _EmissiveColor.rgb * base.rgb;

#if (_LIGHT2_ON == 1)
        vec3 lightDir2 = normalize(-_LightDir2.xyz);
        vec3 lightColor2 = _LightColor2.rgb;
        float nl2 = max(dot(normal, lightDir2), 0.0);
        diffuse += c.rgb * nl2 * lightColor2;
#endif

	    c.rgb = diffuse * (1.0 - reflectivity) + specular + gi + emissive;

#if (_NORMALMAP_ON == 1)
#if (_HAIR_ANISO_ON == 1)
        vec3 binormal = vec3(vTSpace0.y, vTSpace1.y, vTSpace2.y);
        binormal = normalize(binormal);
        
        vec3 aniso = texture2D(_AnisoMap, uv).rgb;
        float anisoShift = aniso.g;
        float anisoMask = aniso.b;
        vec3 t1 = ShiftTangent(binormal, normal, _PrimaryShift + anisoShift);
        vec3 t2 = ShiftTangent(binormal, normal, _SecondaryShift + anisoShift);
        vec3 spec1 = StrandSpecular(t1, viewDir, lightDir, _AnisoSpecMultiplier) * _AnisoSpecColor.rgb * _AnisoSpec;
        vec3 spec2 = StrandSpecular(t2, viewDir, lightDir, _AnisoSpecMultiplier2) * _AnisoSpecColor2.rgb * _AnisoSpec;

        c.rgb += spec1 * lightColor;
        c.rgb += spec2 * anisoMask * lightColor;
#endif
#endif

        return c;
    }
]]

fs_clip_t = fs .. [[
    void main()
    {
        vec2 uv = vUV;
        vec4 base = texture2D(_MainTex, uv);
#if (_SRGB_ON == 1)
        base.rgb = pow(base.rgb, vec3(2.2));
#endif
        vec4 c = base * _Color;

        if (c.a - _Cutoff < 0.0)
        {
            discard;
        }

        c = frag(base, c);
        c.a = 0.0;

        gl_FragColor = c;
    }
]]

fs_clip_o = fs .. [[
    void main()
    {
        vec2 uv = vUV;
        vec4 base = texture2D(_MainTex, uv);
#if (_SRGB_ON == 1)
        base.rgb = pow(base.rgb, vec3(2.2));
#endif
        vec4 c = base * _Color;

        if (_Cutoff - c.a < 0.0)
        {
            discard;
        }

        c = frag(base, c);

        gl_FragColor = c;
    }
]]

--[[
    Cull
	    Back | Front | Off
    ZTest
	    Less | Greater | LEqual | GEqual | Equal | NotEqual | Always
    ZWrite
	    On | Off
    Blend
	    Off / SrcBlendMode DstBlendMode
	    One Zero SrcColor SrcAlpha DstColor DstAlpha OneMinusSrcColor OneMinusSrcAlpha OneMinusDstColor OneMinusDstAlpha
    Queue
        Background | Geometry | AlphaTest | Transparent | Overlay
]]

local rs_clip_t = {
    Cull = Off,
    ZTest = LEqual,
    ZWrite = On,
    Blend = Off,
    SrcBlendMode = SrcAlpha,
    DstBlendMode = OneMinusSrcAlpha,
    Queue = Transparent,
}

local rs_clip_o = {
    Cull = Off,
    ZTest = LEqual,
    ZWrite = Off,
    Blend = On,
    SrcBlendMode = SrcAlpha,
    DstBlendMode = OneMinusSrcAlpha,
    Queue = Transparent,
}

local pass_clip_t = {
    vs = vs,
    fs = fs_clip_t,
    rs = rs_clip_t,
}

local pass_clip_o = {
    vs = vs,
    fs = fs_clip_o,
    rs = rs_clip_o,
}

-- return pass array
return {
    pass_clip_t,
    pass_clip_o
}
