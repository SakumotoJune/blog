local shaderFeatures = [[
#ifndef _SRGB_ON
#define _SRGB_ON 0
#endif
#ifndef _ALPHATEST_ON
#define _ALPHATEST_ON 0
#endif
#ifndef _LIGHT2_ON
#define _LIGHT2_ON 0
#endif
#ifndef _FRAME_ANIM_ON
#define _FRAME_ANIM_ON 0
#endif
#ifndef _OFFSET_ANIM_ON
#define _OFFSET_ANIM_ON 0
#endif
#ifndef _VIEW_SPACE_LIGHTING_ON
#define _VIEW_SPACE_LIGHTING_ON 0
#endif
#ifndef _NORMALMAP_ON
#define _NORMALMAP_ON 0
#endif
#ifndef _PARALLAX_ON
#define _PARALLAX_ON 0
#endif
#ifndef _ALPHABLEND_ON
#define _ALPHABLEND_ON 0
#endif
#ifndef _ALPHABLEND_ADD_ON
#define _ALPHABLEND_ADD_ON 0
#endif
#ifndef _CULLOFF_ON
#define _CULLOFF_ON 0
#endif
#ifndef _SKIN_ON
#define _SKIN_ON 0
#endif
#ifndef _BLEND_SHAPE_ON
#define _BLEND_SHAPE_ON 0
#endif
#ifndef OF_WASM
#define OF_WASM 0
#endif
#ifndef SHADOWMAP
#define SHADOWMAP 0
#endif
]]

vs = shaderFeatures .. [[
#if (_SKIN_ON == 1)
#if (OF_WASM == 1)
    uniform vec4 uBones[90];
#else
    uniform vec4 uBones[210];
#endif
#endif
#if (_PARALLAX_ON == 1)   
    uniform vec4 uWorldCameraPos;
#endif
    uniform mat4 uWorldMatrix;
    uniform mat4 uViewMatrix;
    uniform mat4 uProjectionMatrix;

    uniform vec4 _Time;

	uniform vec4 _UVScaleOffset;

#if (_FRAME_ANIM_ON == 1)
    uniform float _FrameCount;
    uniform float _FrameX;
    uniform float _FrameY;
    uniform float _FrameRate;
#endif

#if (_OFFSET_ANIM_ON == 1)
    uniform vec4 _OffsetSpeed;
#endif

    attribute vec4 aPosition;
    attribute vec2 aTextureCoord;
    attribute vec3 aNormal;
    attribute vec4 aTangent;

#if (_SKIN_ON == 1)
    attribute vec4 aBlendWeight;
    attribute vec4 aBlendIndex;
#endif

    varying vec2 vUV;

#if (_NORMALMAP_ON == 1)
    varying vec4 vTSpace0;
    varying vec4 vTSpace1;
    varying vec4 vTSpace2;
#if (_PARALLAX_ON == 1)    
    varying vec4 vTSpaceViewDir;
#endif
#else
    varying vec3 vPos;
    varying vec3 vNormal;
#endif

#if (SHADOWMAP == 1)
    uniform mat4 uLightViewProjectionMatrix;
    varying vec4 vPosLighProj;
#endif

#if (_BLEND_SHAPE_ON == 1)
    attribute float aVertexIndex;
    uniform sampler2D uBlendShapeTexture;
    uniform sampler2D uBlendShapeWeightTexture;

    int combine_int(vec2 v)
    {
        return int(v.x) * 256 + int(v.y);
    }

    vec4 sample_weight_vec(int i, int w, int h)
    {
        float x = mod(float(i), float(w)) / float(w - 1);
        float y = float(i / w) / float(h - 1);
        return texture2D(uBlendShapeWeightTexture, vec2(x, y));
    }
#endif

    void main()
    {
        vec4 vertex = aPosition;
        vec3 normal = aNormal;
        vec4 tangent = aTangent;

#if (_BLEND_SHAPE_ON == 1)
        {
            vec4 v0 = texture2D(uBlendShapeWeightTexture, vec2(0, 0));
            int weightTextureWidth = combine_int(v0.xy);
            int weightTextureHeight = combine_int(v0.zw);
            vec4 v1 = sample_weight_vec(1, weightTextureWidth, weightTextureHeight);
            int weightCount = combine_int(v1.xy);
            int vertexCount = combine_int(v1.zw);
            vec4 v2 = sample_weight_vec(2, weightTextureWidth, weightTextureHeight);
            int shapeTextureWidth = combine_int(v2.xy);
            int shapeTextureHeight = combine_int(v2.zw);
            int vertexIndex = int(aVertexIndex);

            const int WeightCountMax = 100;
            for (int i = 0; i < WeightCountMax; ++i)
            {
                if (i >= weightCount)
                {
                    break;
                }

                vec4 vi = sample_weight_vec(3 + i, weightTextureWidth, weightTextureHeight);
                int shapeIndex = combine_int(vi.xy);
                float weight = vi.z;

                int vectorIndex = vertexCount * shapeIndex + vertexIndex;
                float x = float(mod(float(vectorIndex), float(shapeTextureWidth))) / float(shapeTextureWidth - 1);
                float y = float(vectorIndex / shapeTextureWidth) / float(shapeTextureHeight - 1);
                vec4 vertexOffset = texture2D(uBlendShapeTexture, vec2(x, y));
                vertex.xyz += vertexOffset.xyz * weight;

                vectorIndex = vertexCount * weightCount + vertexCount * shapeIndex + vertexIndex;
                x = float(mod(float(vectorIndex), float(shapeTextureWidth))) / float(shapeTextureWidth - 1);
                y = float(vectorIndex / shapeTextureWidth) / float(shapeTextureHeight - 1);
                vec4 normalOffset = texture2D(uBlendShapeTexture, vec2(x, y));
                normal.xyz += normalOffset.xyz * weight;

                vectorIndex = vertexCount * weightCount * 2 + vertexCount * shapeIndex + vertexIndex;
                x = float(mod(float(vectorIndex), float(shapeTextureWidth))) / float(shapeTextureWidth - 1);
                y = float(vectorIndex / shapeTextureWidth) / float(shapeTextureHeight - 1);
                vec4 tangentOffset = texture2D(uBlendShapeTexture, vec2(x, y));
                tangent.xyz += tangentOffset.xyz * weight;
            }
        }
#endif

        mat4 worldMatrix;
        
#if (_SKIN_ON == 1)
        // skin mesh
        {
            int index_0 = int(aBlendIndex.x);
            int index_1 = int(aBlendIndex.y);
            int index_2 = int(aBlendIndex.z);
            int index_3 = int(aBlendIndex.w);
            float weights_0 = aBlendWeight.x;
            float weights_1 = aBlendWeight.y;
            float weights_2 = aBlendWeight.z;
            float weights_3 = aBlendWeight.w;
            mat4 bone_0 = mat4(uBones[index_0*3], uBones[index_0*3+1], uBones[index_0*3+2], vec4(0.0, 0.0, 0.0, 1.0));
            mat4 bone_1 = mat4(uBones[index_1*3], uBones[index_1*3+1], uBones[index_1*3+2], vec4(0.0, 0.0, 0.0, 1.0));
            mat4 bone_2 = mat4(uBones[index_2*3], uBones[index_2*3+1], uBones[index_2*3+2], vec4(0.0, 0.0, 0.0, 1.0));
            mat4 bone_3 = mat4(uBones[index_3*3], uBones[index_3*3+1], uBones[index_3*3+2], vec4(0.0, 0.0, 0.0, 1.0));
            worldMatrix = bone_0 * weights_0 + bone_1 * weights_1 + bone_2 * weights_2 + bone_3 * weights_3;
        }

        // transpose
        {
            float temp = worldMatrix[0][1];
            worldMatrix[0][1] = worldMatrix[1][0];
            worldMatrix[1][0] = temp;

            temp = worldMatrix[0][2];
            worldMatrix[0][2] = worldMatrix[2][0];
            worldMatrix[2][0] = temp;

            temp = worldMatrix[0][3];
            worldMatrix[0][3] = worldMatrix[3][0];
            worldMatrix[3][0] = temp;

            temp = worldMatrix[1][2];
            worldMatrix[1][2] = worldMatrix[2][1];
            worldMatrix[2][1] = temp;

            temp = worldMatrix[1][3];
            worldMatrix[1][3] = worldMatrix[3][1];
            worldMatrix[3][1] = temp;

            temp = worldMatrix[2][3];
            worldMatrix[2][3] = worldMatrix[3][2];
            worldMatrix[3][2] = temp;
        }
#else
        worldMatrix = uWorldMatrix;
#endif
        
        gl_Position = uProjectionMatrix * uViewMatrix * worldMatrix * vertex;

#if (_FRAME_ANIM_ON == 1)
		int frame = int(_Time.y * _FrameRate);
		frame = frame - (frame / int(_FrameCount)) * int(_FrameCount);
		int x = frame - (frame / int(_FrameX)) * int(_FrameX);
		int y = frame / int(_FrameX);
		float w = 1.0 / float(_FrameX);
		float h = 1.0 / float(_FrameY);

		vec4 scale_offset;
		scale_offset.x = w;
		scale_offset.y = h;
		scale_offset.z = float(x) * w;
		scale_offset.w = float(y) * h;

		vUV = aTextureCoord * scale_offset.xy + scale_offset.zw;
#else
        vUV = aTextureCoord * _UVScaleOffset.xy + _UVScaleOffset.zw;
#endif

#if (_OFFSET_ANIM_ON == 1)
        vUV += _OffsetSpeed.xy * _Time.y;
#endif

        vec3 posWorld = (worldMatrix * vertex).xyz;
        vec3 normalWorld = normalize((worldMatrix * vec4(normal, 0.0)).xyz);

        vec3 out_pos = posWorld;
        vec3 out_normal = normalWorld;

#if (_VIEW_SPACE_LIGHTING_ON == 1)
        out_pos = (uViewMatrix * vec4(posWorld, 1.0)).xyz;
        out_normal = normalize((uViewMatrix * vec4(normalWorld, 0.0)).xyz);
#endif 
#if (_NORMALMAP_ON == 1)
        //worldspace
	    vec3 tangentWorld = normalize((worldMatrix * vec4(tangent.xyz, 0.0)).xyz);
        vec3 binormalWorld = normalize(cross(normalWorld, tangentWorld) * tangent.w);
#if (_PARALLAX_ON == 1)
        vec3 viewDir = normalize(uWorldCameraPos.xyz - posWorld);
        vTSpaceViewDir.x = dot(vec3(tangentWorld.x, tangentWorld.y, tangentWorld.z), viewDir);
        vTSpaceViewDir.y = dot(vec3(binormalWorld.x, binormalWorld.y, binormalWorld.z), viewDir);
        vTSpaceViewDir.z = dot(vec3(normalWorld.x, normalWorld.y, normalWorld.z), viewDir);
#endif

#if (_VIEW_SPACE_LIGHTING_ON == 1)
        vec3 tangentView = (uViewMatrix * vec4(tangentWorld, 0.0)).xyz;
        vec3 binormalView = normalize(cross(out_normal, tangentView) * tangent.w);
        vTSpace0 = vec4(tangentView.x, binormalView.x, out_normal.x, out_pos.x);
        vTSpace1 = vec4(tangentView.y, binormalView.y, out_normal.y, out_pos.y);
        vTSpace2 = vec4(tangentView.z, binormalView.z, out_normal.z, out_pos.z);
#else
        vTSpace0 = vec4(tangentWorld.x, binormalWorld.x, normalWorld.x, out_pos.x);
        vTSpace1 = vec4(tangentWorld.y, binormalWorld.y, normalWorld.y, out_pos.y);
        vTSpace2 = vec4(tangentWorld.z, binormalWorld.z, normalWorld.z, out_pos.z);
#endif 

#else
        vPos = out_pos;
        vNormal = out_normal;
#endif

#if (SHADOWMAP == 1)
        vPosLighProj = uLightViewProjectionMatrix * worldMatrix * vertex;
#endif
    }
]]

fs = shaderFeatures .. [[
    precision highp float;

    uniform vec4 uWorldCameraPos;
    uniform sampler2D _MainTex;
    uniform sampler2D _NormalMap;
    uniform sampler2D _ParallaxMap;
    uniform sampler2D _SpecMap;
    uniform sampler2D _EmissiveMap;
    uniform sampler2D _Mask;
    uniform samplerCube _EnvMap;

#if (_ALPHATEST_ON == 1)
    uniform float _Cutoff;
#endif

    uniform vec4 _Color;
    uniform vec4 _SpecColor;
    uniform vec4 _EmissiveColor;
    uniform vec4 _LightDir;
    uniform vec4 _LightColor;
    uniform vec4 _AmbientColor;
    uniform vec4 _EnvColor;
    uniform float _Smoothness;
#if (_NORMALMAP_ON == 1)
    uniform float _HeightScale;
#endif
    uniform float _FirstSpecPow;
    uniform float _FirstSpecIntensity;
    uniform float _SecondSpecPow;
    uniform float _SecondSpecItensity;
    uniform float _ShiftValue;
    uniform float _ReflectStrength;
    uniform float _TotalLightStrength;
#if (_LIGHT2_ON == 1)
    uniform vec4 _LightDir2;
    uniform vec4 _LightColor2;
#endif

    varying vec2 vUV;

#if (_NORMALMAP_ON == 1)
    varying vec4 vTSpace0;
    varying vec4 vTSpace1;
    varying vec4 vTSpace2;
#if (_PARALLAX_ON == 1)    
    varying vec4 vTSpaceViewDir;
#endif
#else
    varying vec3 vPos;
    varying vec3 vNormal;
#endif

#if (SHADOWMAP == 1)
    uniform float _ShadowStrength;
    uniform float _ShadowZBias;
    uniform float _ShadowSlopeBias;
    uniform float _ShadowFilterRadius;
    uniform highp sampler2D _ShadowMap;
    varying vec4 vPosLighProj;

    float texture_shadow(vec2 uv)
    {
        if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0)
        {
            return 1.0;
        }
        else
        {
            return texture2D(_ShadowMap, vec2(uv.x, 1.0 - uv.y)).r;
        }
    }

    float sample_shadow(vec4 posLightProj, vec2 filterRadius, float zBias)
    {
        vec2 uv = posLightProj.xy * 0.5 + 0.5;
        uv.y = 1.0 - uv.y;
        float z = posLightProj.z * 0.5 + 0.5;
        if (z <= 0.0 || z >= 1.0)
        {
            return 0.0;
        }

        float shadow = 0.0;
        for (int i = -1; i <= 1; ++i)
        {
            for (int j = -1; j <= 1; ++j)
            {
                vec2 offset = vec2(float(i), float(j)) * filterRadius;
                float depth = texture_shadow(uv + offset);
                if (z - zBias > depth)
                {
                    shadow += 1.0;
                }
            }
        }
        return shadow / 9.0;
    }
#endif

#if (_PARALLAX_ON == 1)
    vec2 ParallaxOffset1Step (float h, float height, vec3 viewDir)
    {
        h = h * height - height/2.0;
        vec3 v = normalize(viewDir);
        v.z += 0.42;
        return h * (v.xy / v.z);
    }
    vec2 Parallax (vec2 texcoords, vec3 viewDir)
    {
        float h = texture2D(_ParallaxMap, texcoords.xy).g;
        vec2 offset = ParallaxOffset1Step (h, _HeightScale, viewDir);
        return vec2(texcoords.xy + offset);
    }
#endif

    float saturate(float value)
    {
        return clamp(value, 0.0, 1.0);
    }

    float Luminance(vec3 v)
    {
#if (_SRGB_ON == 1)
        vec4 ColorSpaceLuminance = vec4(0.0396819152, 0.458021790, 0.00609653955, 1.0);
#else
        vec4 ColorSpaceLuminance = vec4(0.22, 0.707, 0.071, 0.0);
#endif
        return dot(v.rgb, ColorSpaceLuminance.rgb);
    }

    vec2 pow4(vec2 x) { return x * x * x * x; }

    void main()
    {
        vec2 uv = vUV;
#if (_PARALLAX_ON == 1)
        uv = Parallax(vUV, vTSpaceViewDir.xyz);
#endif
	    vec4 base = texture2D(_MainTex, uv);
#if (_SRGB_ON == 1)
        base.rgb = pow(base.rgb, vec3(2.2));
#endif
        vec4 c = base * _Color;

#if (_ALPHATEST_ON == 1)
        if (c.a - _Cutoff < 0.001)
        {
            discard;
        }
#endif

#if (_NORMALMAP_ON == 1)
	    vec3 n = texture2D(_NormalMap, uv).rgb * 2.0 - 1.0;
        n.z = sqrt(1.0 - n.x * n.x - n.y * n.y);
        vec3 normal = normalize(vec3(dot(vTSpace0.xyz, n), dot(vTSpace1.xyz, n), dot(vTSpace2.xyz, n)));
        vec3 pos = vec3(vTSpace0.w, vTSpace1.w, vTSpace2.w);
#else
        vec3 normal = normalize(vNormal);
        vec3 pos = vPos;
#endif

#if (_VIEW_SPACE_LIGHTING_ON == 1)
        vec3 viewDir = normalize(-pos);
#else
        vec3 viewDir = normalize(uWorldCameraPos.xyz - pos);
#endif
        vec3 lightDir = normalize(-_LightDir.xyz);
        //lightDir = _LightDir.xyz;
	    vec3 lightColor = _LightColor.rgb;

	    float nl = max(dot(normal, lightDir), 0.0);
	    vec3 h = normalize(lightDir + viewDir);
	    float nh = max(dot(normal, h), 0.0);
	    float nv = max(dot(normal, viewDir), 0.0);
	    vec3 ref = reflect(viewDir, normal);

        vec4 specMap = texture2D(_SpecMap, uv);
        vec3 specColor = _SpecColor.rgb * specMap.rgb;
	    float smoothness = _Smoothness * specMap.a;
        float roughness = 1.0 - smoothness;
	    float reflectivity = max(max(specColor.r, specColor.g), specColor.b);

	    vec2 rlp4 = pow4(vec2(dot(ref, lightDir), 1.0 - nv));
	    float fresnel = rlp4.y;
	    float grazing = clamp(smoothness + reflectivity, 0.0, 1.0);

	    float lh = max(dot(lightDir, h), 0.0);
	    float roughness2 = roughness * roughness;
	    float a = roughness2;
	    float a2 = a * a;
	    float d = nh * nh * (a2 - 1.0) + 1.00001;
	    float spec = a2 / (max(0.1, lh * lh) * (roughness2 + 0.5) * (d * d) * 4.0);
	    spec = max(spec - 1e-4, 0.0);
	
	    ref.y = -ref.y;
	    vec3 env = textureCube(_EnvMap, -ref).rgb;
        vec3 emi = texture2D(_EmissiveMap, uv).rgb;

#if (_SRGB_ON == 1)
        env = pow(env, vec3(2.2));
        emi = pow(emi, vec3(2.2));
#endif

	    vec3 ambient = c.rgb * _AmbientColor.rgb;
        vec3 diffuse = c.rgb * nl * lightColor;
        
        vec3 halfDir = viewDir;
        float firstSpec = pow(saturate(dot(normal, halfDir)), _FirstSpecPow) * _FirstSpecIntensity;
        //lightDir = -lightDir;
        float secondSpec = pow(saturate(dot(normal, normalize(viewDir * _ShiftValue + lightDir * normal))), _SecondSpecPow) * _SecondSpecItensity;

        vec4 mask = texture2D(_Mask, uv);
#if (_SRGB_ON == 1)
        mask.rgb = pow(mask.rgb, vec3(2.2));
#endif 
        vec3 specular = (firstSpec + secondSpec) * mask.g * specColor * lightColor;
        //vec3 specular = spec * specColor * lightColor;
        
	    //vec3 gi = env * _EnvColor.rgb * 2.0 * mix(specColor, vec3(1.0) * grazing, fresnel);
        vec3 emissive = emi * _EmissiveColor.rgb * base.rgb;

#if (_LIGHT2_ON == 1)
        vec3 lightDir2 = normalize(-_LightDir2.xyz);
        vec3 lightColor2 = _LightColor2.rgb;
        float nl2 = max(dot(normal, lightDir2), 0.0);
        diffuse += c.rgb * nl2 * lightColor2;
#endif

#if (SHADOWMAP == 1)
        float shadowZBias = _ShadowZBias + _ShadowSlopeBias * tan(acos(nl));
        float shadow = sample_shadow(vPosLighProj / vPosLighProj.w, vec2(_ShadowFilterRadius), shadowZBias) * _ShadowStrength;
        diffuse *= 1.0 - shadow;
#endif
        //gi = 0;
        c.rgb = (ambient + diffuse) * (1.0 - reflectivity) + specular + emissive + Luminance(env) * mask.r * _ReflectStrength;
        gl_FragColor = c;
    }
]]

--[[
    Cull
	    Back | Front | Off
    ZTest
	    Less | Greater | LEqual | GEqual | Equal | NotEqual | Always
    ZWrite
	    On | Off
    Blend
	    Off / SrcBlendMode DstBlendMode
	    One Zero SrcColor SrcAlpha DstColor DstAlpha OneMinusSrcColor OneMinusSrcAlpha OneMinusDstColor OneMinusDstAlpha
    Queue
        Background | Geometry | AlphaTest | Transparent | Overlay
]]

local rs = {
    Cull = Back,
    ZTest = LEqual,
    ZWrite = On,
    Blend = Off,
    SrcBlendMode = SrcAlpha,
    DstBlendMode = OneMinusSrcAlpha,
    Queue = Geometry,
}

local pass = {
    vs = vs,
    fs = fs,
    rs = rs,
}

-- return pass array
return {
    pass
}
