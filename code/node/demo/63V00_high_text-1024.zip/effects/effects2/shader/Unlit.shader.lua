local shaderFeatures = [[
#ifndef _SRGB_ON
#define _SRGB_ON 0
#endif
#ifndef _ALPHATEST_ON
#define _ALPHATEST_ON 0
#endif
#ifndef _FRAME_ANIM_ON
#define _FRAME_ANIM_ON 0
#endif
#ifndef _OFFSET_ANIM_ON
#define _OFFSET_ANIM_ON 0
#endif
#ifndef _ALPHABLEND_ON
#define _ALPHABLEND_ON 0
#endif
#ifndef _ALPHABLEND_ADD_ON
#define _ALPHABLEND_ADD_ON 0
#endif
#ifndef _CULLOFF_ON
#define _CULLOFF_ON 0
#endif
#ifndef _SKIN_ON
#define _SKIN_ON 0
#endif
#ifndef OF_WASM
#define OF_WASM 0
#endif
]]

vs = shaderFeatures .. [[
#if (_SKIN_ON == 1)
#if (OF_WASM == 1)
    uniform vec4 uBones[90];
#else
    uniform vec4 uBones[210];
#endif
#endif
    uniform mat4 uWorldMatrix;
    uniform mat4 uViewMatrix;
    uniform mat4 uProjectionMatrix;

    uniform vec4 _Time;

	uniform vec4 _UVScaleOffset;

#if (_FRAME_ANIM_ON == 1)
    uniform float _FrameCount;
    uniform float _FrameX;
    uniform float _FrameY;
    uniform float _FrameRate;
#endif

#if (_OFFSET_ANIM_ON == 1)
    uniform vec4 _OffsetSpeed;
#endif

    attribute vec4 aPosition;
    attribute vec2 aTextureCoord;

#if (_SKIN_ON == 1)
    attribute vec4 aBlendWeight;
    attribute vec4 aBlendIndex;
#endif

    varying vec2 vUV;
    void main()
    {
        vec4 vertex = aPosition;
        mat4 worldMatrix;
        
#if (_SKIN_ON == 1)
        // skin mesh
        {
            int index_0 = int(aBlendIndex.x);
            int index_1 = int(aBlendIndex.y);
            int index_2 = int(aBlendIndex.z);
            int index_3 = int(aBlendIndex.w);
            float weights_0 = aBlendWeight.x;
            float weights_1 = aBlendWeight.y;
            float weights_2 = aBlendWeight.z;
            float weights_3 = aBlendWeight.w;
            mat4 bone_0 = mat4(uBones[index_0*3], uBones[index_0*3+1], uBones[index_0*3+2], vec4(0.0, 0.0, 0.0, 1.0));
            mat4 bone_1 = mat4(uBones[index_1*3], uBones[index_1*3+1], uBones[index_1*3+2], vec4(0.0, 0.0, 0.0, 1.0));
            mat4 bone_2 = mat4(uBones[index_2*3], uBones[index_2*3+1], uBones[index_2*3+2], vec4(0.0, 0.0, 0.0, 1.0));
            mat4 bone_3 = mat4(uBones[index_3*3], uBones[index_3*3+1], uBones[index_3*3+2], vec4(0.0, 0.0, 0.0, 1.0));
            worldMatrix = bone_0 * weights_0 + bone_1 * weights_1 + bone_2 * weights_2 + bone_3 * weights_3;
        }

        // transpose
        {
            float temp = worldMatrix[0][1];
            worldMatrix[0][1] = worldMatrix[1][0];
            worldMatrix[1][0] = temp;

            temp = worldMatrix[0][2];
            worldMatrix[0][2] = worldMatrix[2][0];
            worldMatrix[2][0] = temp;

            temp = worldMatrix[0][3];
            worldMatrix[0][3] = worldMatrix[3][0];
            worldMatrix[3][0] = temp;

            temp = worldMatrix[1][2];
            worldMatrix[1][2] = worldMatrix[2][1];
            worldMatrix[2][1] = temp;

            temp = worldMatrix[1][3];
            worldMatrix[1][3] = worldMatrix[3][1];
            worldMatrix[3][1] = temp;

            temp = worldMatrix[2][3];
            worldMatrix[2][3] = worldMatrix[3][2];
            worldMatrix[3][2] = temp;
        }
#else
        worldMatrix = uWorldMatrix;
#endif

        gl_Position = uProjectionMatrix * uViewMatrix * worldMatrix * vertex;

#if (_FRAME_ANIM_ON == 1)
		int frame = int(_Time.y * _FrameRate);
		frame = frame - (frame / int(_FrameCount)) * int(_FrameCount);
		int x = frame - (frame / int(_FrameX)) * int(_FrameX);
		int y = frame / int(_FrameX);
		float w = 1.0 / float(_FrameX);
		float h = 1.0 / float(_FrameY);

		vec4 scale_offset;
		scale_offset.x = w;
		scale_offset.y = h;
		scale_offset.z = float(x) * w;
		scale_offset.w = float(y) * h;

		vUV = aTextureCoord * scale_offset.xy + scale_offset.zw;
#else
        vUV = aTextureCoord * _UVScaleOffset.xy + _UVScaleOffset.zw;
#endif

#if (_OFFSET_ANIM_ON == 1)
        vUV += _OffsetSpeed.xy * _Time.y;
#endif
    }
]]

fs = shaderFeatures .. [[
    precision highp float;
    uniform sampler2D _MainTex;
#if (_ALPHATEST_ON == 1)
    uniform float _Cutoff;
#endif

    uniform vec4 _Color;
    varying vec2 vUV;

    void main()
    {
        vec2 uv = vUV;
	    vec4 base = texture2D(_MainTex, uv);
#if (_SRGB_ON == 1)
        base.rgb = pow(base.rgb, vec3(2.2));
#endif
        vec4 c = base * _Color;
#if (_ALPHATEST_ON == 1)
        if (c.a - _Cutoff < 0.001)
        {
            discard;
        }
#endif
        gl_FragColor = c;
    }
]]

--[[
    Cull
	    Back | Front | Off
    ZTest
	    Less | Greater | LEqual | GEqual | Equal | NotEqual | Always
    ZWrite
	    On | Off
    Blend
	    Off / SrcBlendMode DstBlendMode
	    One Zero SrcColor SrcAlpha DstColor DstAlpha OneMinusSrcColor OneMinusSrcAlpha OneMinusDstColor OneMinusDstAlpha
    Queue
        Background | Geometry | AlphaTest | Transparent | Overlay
]]

local rs = {
    Cull = Back,
    ZTest = LEqual,
    ZWrite = On,
    Blend = Off,
    SrcBlendMode = SrcAlpha,
    DstBlendMode = OneMinusSrcAlpha,
    Queue = Geometry,
}

local pass = {
    vs = vs,
    fs = fs,
    rs = rs,
}

-- return pass array
return {
    pass
}
