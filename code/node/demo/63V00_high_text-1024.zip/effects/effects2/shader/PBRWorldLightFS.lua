fs = [[
#ifndef SHADOWMAP
    #define SHADOWMAP 0
#endif

    precision highp float;

#if (SHADOWMAP == 1)
    uniform float _ShadowStrength;
    uniform float _ShadowZBias;
    uniform float _ShadowSlopeBias;
    uniform float _ShadowFilterRadius;
    uniform highp sampler2D _ShadowMap;
    varying vec4 vPosLighProj;

    float texture_shadow(vec2 uv)
    {
        if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0)
        {
            return 1.0;
        }
        else
        {
            return texture2D(_ShadowMap, vec2(uv.x, 1.0 - uv.y)).r;
        }
    }

    float sample_shadow(vec4 posLightProj, vec2 filterRadius, float zBias)
    {
        vec2 uv = posLightProj.xy * 0.5 + 0.5;
        uv.y = 1.0 - uv.y;
        float z = posLightProj.z * 0.5 + 0.5;
        if (z <= 0.0 || z >= 1.0)
        {
            return 0.0;
        }

        float shadow = 0.0;
        for (int i = -1; i <= 1; ++i)
        {
            for (int j = -1; j <= 1; ++j)
            {
                vec2 offset = vec2(float(i), float(j)) * filterRadius;
                float depth = texture_shadow(uv + offset);
                if (z - zBias > depth)
                {
                    shadow += 1.0;
                }
            }
        }
        return shadow / 9.0;
    }
#endif

    uniform vec4 uWorldCameraPos;
    uniform sampler2D _MainTex;
    uniform sampler2D _Normal;
    uniform sampler2D _SpecMap;
    uniform sampler2D _EmissiveMap;
    uniform samplerCube _CubeMap;

    uniform vec4 _Color;
    uniform vec4 _Spec;
    uniform vec4 _Emissive;
    uniform vec4 _LightDir;
    uniform vec4 _LightColor;
    uniform vec4 _AmbientColor;
    uniform vec4 _EnvColor;
    uniform vec4 _DissBorderColor1;
    uniform vec4 _DissBorderColor2;
    uniform float _Smoothness;

    varying vec2 vUV;
    varying vec4 vTSpace0;
    varying vec4 vTSpace1;
    varying vec4 vTSpace2;

    vec2 pow4(vec2 x) { return x * x * x * x; }

    vec4 pbr()
    {
	    vec2 uv = vUV;

	    vec4 base = texture2D(_MainTex, uv);
        vec4 c = base * _Color;
	    vec3 n = texture2D(_Normal, uv).rgb * 2.0 - 1.0;

	    vec4 specMap = texture2D(_SpecMap, uv);
	    vec3 emissive = texture2D(_EmissiveMap, uv).rgb * _Emissive.rgb * base.rgb;

	    vec3 posWorld = vec3(vTSpace0.w, vTSpace1.w, vTSpace2.w);
	    vec3 normal = normalize(vec3(dot(vTSpace0.xyz, n), dot(vTSpace1.xyz, n), dot(vTSpace2.xyz, n)));
	    vec3 lightDir = normalize(-_LightDir.xyz);
	    vec3 viewDir = normalize(uWorldCameraPos.xyz - posWorld);
	    vec3 lightColor = _LightColor.rgb;

	    float nl = max(dot(normal, lightDir), 0.0);
	    vec3 h = normalize(lightDir + viewDir);
	    float nh = max(dot(normal, h), 0.0);
	    float nv = max(dot(normal, viewDir), 0.0);
	    vec3 ref = reflect(viewDir, normal);

	    vec3 specColor = _Spec.rgb * specMap.rgb;
	    float smoothness = _Smoothness * specMap.a;
	    float reflectivity = max(max(specColor.r, specColor.g), specColor.b);

	    vec2 rlp4 = pow4(vec2(dot(ref, lightDir), 1.0 - nv));
	    float fresnel = rlp4.y;
	    float grazing = clamp(smoothness + reflectivity, 0.0, 1.0);

	    float lh = max(dot(lightDir, h), 0.0);
	    float roughness = 1.0 - smoothness;
	    float roughness2 = roughness * roughness;
	    float a = roughness2;
	    float a2 = a * a;
	    float d = nh * nh * (a2 - 1.0) + 1.00001;
	    float spec = a2 / (max(0.1, lh * lh) * (roughness2 + 0.5) * (d * d) * 4.0);
	    spec = max(spec - 1e-4, 0.0);
	
	    ref.y = -ref.y;
	    vec3 env = textureCube(_CubeMap, -ref).rgb * _EnvColor.rgb * 2.0;

        vec3 ambient = c.rgb * _AmbientColor.rgb;
	    vec3 diffuse = c.rgb * nl * lightColor;
	    vec3 specular = spec * specColor * lightColor;
	    vec3 gi = env * mix(specColor, vec3(1.0) * grazing, fresnel);

#if (SHADOWMAP == 1)
        float shadowZBias = _ShadowZBias + _ShadowSlopeBias * tan(acos(nl));
        float shadow = sample_shadow(vPosLighProj / vPosLighProj.w, vec2(_ShadowFilterRadius), shadowZBias) * _ShadowStrength;
        diffuse *= 1.0 - shadow;
#endif

	    c.rgb = (ambient + diffuse) * (1.0 - reflectivity) + specular + gi + emissive;

        return c;
    }
]]
