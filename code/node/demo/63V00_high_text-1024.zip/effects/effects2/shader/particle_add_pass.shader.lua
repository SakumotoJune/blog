vs = [[
    uniform mat4 uViewProjectionMatrix;

    attribute vec3 aPosition;
    attribute vec4 aColor;
    attribute vec2 aTextureCoord;

    varying vec4 vColor;
    varying vec2 vTexCoord;

    void main() 
    {
	    gl_Position = uViewProjectionMatrix * vec4(aPosition, 1.0);
	    vColor = aColor;
        vTexCoord = aTextureCoord;
    }
]]

fs = [[
    precision highp float;

    uniform vec4 _TintColor;
    uniform sampler2D _MainTex;

    varying vec4 vColor;
    varying vec2 vTexCoord;

    void main()
    {
        vec4 color = 2.0 * vColor * _TintColor * texture2D(_MainTex, vTexCoord);
        gl_FragColor = color;
    }
]]

--[[
    Cull
	    Back | Front | Off
    ZTest
	    Less | Greater | LEqual | GEqual | Equal | NotEqual | Always
    ZWrite
	    On | Off
    Blend
	    Off / SrcBlendMode DstBlendMode
	    One Zero SrcColor SrcAlpha DstColor DstAlpha OneMinusSrcColor OneMinusSrcAlpha OneMinusDstColor OneMinusDstAlpha
]]

local rs = {
    Cull = Off,
    ZTest = LEqual,
    ZWrite = Off,
    Blend = On,
    SrcBlendMode = SrcAlpha,
    DstBlendMode = One,
    Queue = Transparent,
}

local pass = {
    vs = vs,
    fs = fs,
    rs = rs,
}

-- return pass array
return {
    pass
}
