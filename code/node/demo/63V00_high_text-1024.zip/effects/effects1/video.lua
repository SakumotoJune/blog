-- Change history:
--   2021/04/20 : Optimize.
--   2021/09/17 : add renderToRT in animation.
--   2021/09/27 : fix video texture reuse bug

TAG = "OrangeFilter-Video"
OF_LOGI(TAG, "Call Video lua script!")
local Config = require "config"
local EffectList = require "effectlist"

local Filter = {
    name = "sticker",
    vs = [[
		precision mediump float;
		uniform mat4 uMVP;
        attribute vec4 aPosition;
        attribute vec4 aTextureCoord;
        varying vec2 vTexCoord;

        void main()
        {
            gl_Position = uMVP * aPosition;
            vTexCoord = aTextureCoord.xy;
        }
        ]],

    fs = [[
        precision mediump float;
		uniform sampler2D uTexture0;
		uniform vec4 uColor;
		uniform float uTileX;
		uniform float uTileY;
		uniform float uAnimFPS;
		uniform float uTimestamp;
        varying vec2 vTexCoord;

        void main()
        {
			vec2 uv = vTexCoord;
            int idx = int(mod(uTimestamp * uAnimFPS / 1000.0, uTileX * uTileY));
			int rowIdx = int(mod(float(idx) / uTileX, uTileY));
			int colIdx = int(mod(float(idx), uTileX));

			uv.x = uv.x / uTileX + float(colIdx) / uTileX;
			uv.y = uv.y / uTileY + float(rowIdx) / uTileY;

			gl_FragColor = texture2D(uTexture0, uv) * uColor;
        }
        ]],
	mask_fs = [[
			precision mediump float;
			uniform sampler2D uTexture0;
			uniform sampler2D uTexture1;
			uniform vec4 uColor;
			uniform float uTileX;
			uniform float uTileY;
			uniform float uAnimFPS;
			uniform float uTimestamp;
			varying vec2 vTexCoord;
	
			void main()
			{
				vec2 uv = vTexCoord;
				int idx = int(mod(uTimestamp * uAnimFPS / 1000.0, uTileX * uTileY));
				int rowIdx = int(mod(float(idx) / uTileX, uTileY));
				int colIdx = int(mod(float(idx), uTileX));
	
				uv.x = uv.x / uTileX + float(colIdx) / uTileX;
				uv.y = uv.y / uTileY + float(rowIdx) / uTileY;
	
				vec4 mask = texture2D(uTexture1, uv);
				vec4 rst = texture2D(uTexture0, uv) * uColor;

				gl_FragColor = vec4(rst.rgb, rst.a * (1.0 - mask.r));
			}
			]],

	blend_fs = [[
		precision mediump float;
		uniform sampler2D uTexture0;
		uniform sampler2D uTexture1;
		uniform int uBlendMode;
		uniform float uOpacity;
		varying vec2 vTexCoord;

		vec3 blendfunc(vec3 base, vec3 blend, int mode)
		{
			vec3 res = base;
			if (mode == 0) { // Normal
				res = blend.rgb;
			}
			else if (mode == 1) { // Screen, lvse
				res.r = 1.0 - ((1.0 - base.r) * (1.0 - blend.r));
				res.g = 1.0 - ((1.0 - base.g) * (1.0 - blend.g));
				res.b = 1.0 - ((1.0 - base.b) * (1.0 - blend.b));
			}
			else if (mode == 2) { // Darken, bianan
				res = min(base, blend);
			}
			else if (mode == 3) { // Lighten, bianliang
				res = max(base, blend);
			}
			else if (mode == 4) { // Overlay, diejia
				res.r = (base.r < 0.5 ? (2.0 * base.r * blend.r) : (1.0 - 2.0 * (1.0 - base.r) * (1.0 - blend.r)));
				res.g = (base.g < 0.5 ? (2.0 * base.g * blend.g) : (1.0 - 2.0 * (1.0 - base.g) * (1.0 - blend.g)));
				res.b = (base.b < 0.5 ? (2.0 * base.b * blend.b) : (1.0 - 2.0 * (1.0 - base.b) * (1.0 - blend.b)));
			}
			else if (mode == 5) { // HardLight, qiangguang
				res.r = (blend.r < 0.5 ? (2.0 * blend.r * base.r) : (1.0 - 2.0 * (1.0 - blend.r) * (1.0 - base.r)));
				res.g = (blend.g < 0.5 ? (2.0 * blend.g * base.g) : (1.0 - 2.0 * (1.0 - blend.g) * (1.0 - base.g)));
				res.b = (blend.b < 0.5 ? (2.0 * blend.b * base.b) : (1.0 - 2.0 * (1.0 - blend.b) * (1.0 - base.b)));
			}
			else if (mode == 6) { // SoftLight, rouguang
				res.r = ((blend.r < 0.5)
				? (2.0 * base.r * blend.r + base.r * base.r * (1.0 - 2.0 * blend.r))
				: (sqrt(base.r) * (2.0 * blend.r - 1.0) + 2.0 * base.r * (1.0 - blend.r)));
				res.g = ((blend.g < 0.5)
				? (2.0 * base.g * blend.g + base.g * base.g * (1.0 - 2.0 * blend.g))
				: (sqrt(base.g) * (2.0 * blend.g - 1.0) + 2.0 * base.g * (1.0 - blend.g)));
				res.b = ((blend.b < 0.5)
				? (2.0 * base.b * blend.b + base.b * base.b * (1.0 - 2.0 * blend.b))
				: (sqrt(base.b) * (2.0 * blend.b - 1.0) + 2.0 * base.b * (1.0 - blend.b)));
			}
			else if (mode == 7) { // LinearBurn xianxingjiashen
				res = max(base + blend - vec3(1.0), vec3(0.0));
			}
			else if (mode == 8) { // ColorBurn, yansejiashen
				res.r = ((blend.r == 0.0) ? blend.r : max((1.0 - ((1.0 - base.r) / blend.r)), 0.0));
				res.g = ((blend.g == 0.0) ? blend.g : max((1.0 - ((1.0 - base.g) / blend.g)), 0.0));
				res.b = ((blend.b == 0.0) ? blend.b : max((1.0 - ((1.0 - base.b) / blend.b)), 0.0));
			}
			else if (mode == 9) { // ColorDodge, yansejiandan
				res.r = (blend.r == 1.0) ? 1.0 : base.r/(1.0 - blend.r);
				res.g = (blend.g == 1.0) ? 1.0 : base.g/(1.0 - blend.g);
				res.b = (blend.b == 1.0) ? 1.0 : base.b/(1.0 - blend.b);
			}
			else if (mode == 10) { // Multiply, zhengpiandiedi
				res.r = base.r * blend.r;
				res.g = base.g * blend.g;
				res.b = base.b * blend.b;
			}
			else if (mode == 11) { // Subtract, xiangjian
				//res.r = max(base.r + blend.r -1.0, 0.0);
				//res.g = max(base.g + blend.g -1.0, 0.0);
				//res.b = max(base.b + blend.b -1.0, 0.0);
				res.r = base.r - blend.r;
				res.g = base.g - blend.g;
				res.b = base.b - blend.b;
			}
			else if (mode == 12) { // Add, xiangjia
				res.r = base.r + blend.r;
				res.g = base.g + blend.g;
				res.b = base.b + blend.b;
			}
			else if (mode == 13) { // LinearLight, xianxingguang
				res = (min(vec3(1.0), max(vec3(0.0), ((base.rgb) + vec3(2.0) * (blend.rgb) - vec3(1.0)))));
			}
			else if (mode == 14) { // LinearDodge
				res = base + blend;
			}
			else if (mode == 15) { // Difference, qubie
				res = abs(blend - base);
			}
			else if (mode == 16) { // LighterColor, jiaoqianyanse
				res = ((base.r + base.g + base.b) > (blend.r + blend.g + blend.b)) ? base : blend;
			}
			else if (mode == 17) { // DarkerColor, jiaoshenyanse
				res = ((base.r + base.g + base.b) > (blend.r + blend.g + blend.b)) ? blend : base;
			}
		
			return res;
		}

		void main()
		{
			vec4 base = texture2D(uTexture0, vTexCoord);
			vec4 blend = texture2D(uTexture1, vTexCoord);
			vec3 res = blendfunc(base.rgb, blend.rgb, uBlendMode);
			float alpha = blend.a * uOpacity;
			res = mix(base.rgb, res, alpha);
			gl_FragColor = vec4(res, blend.a * alpha + base.a * (1.0 - alpha));
		}
	]],

	renderPass = nil,
	renderMaskPass = nil,
	blendPass = nil,
	imageTex = nil,
	maskTex  = nil,
	hasMask = false,
	duration = 10,
	context = nil,
	params = {
		tx = 0, ty = 0, rot = 0, scale = 1,
		opacity = 100, beauty = 0, thinface = 0,
		blendMode = 0, blendOpacity = 100,
		brightness  = 0,
		contrast    = 0,
		saturation  = 0,
		sharpen     = 0,
		highlight   = 0,
		shadow      = 0,
		fade        = 0,
		temperature = 0,
		tone        = 0, },
	fSetParamsByMsg = false,
	animation = {
		enter_animation = nil, enter_duration = 1,
		exit_animation = nil, exit_duration = 1,
		loop_animation = nil, loop_duration = 1,
		params = {
			alpha = 1.0,
			position = { 0, 0, 0 },
			scale = { 1.0, 1.0, 1.0 },
			rotation = { 0.0, 0.0, 0.0 },
			localPosition = { 0, 0, 0 },
			localScale = { 1.0, 1.0, 1.0 },
			localRotation = { 0.0, 0.0, 0.0 },

			renderToRT = nil,
		}
		
	},

	debug = 0.0
}

function Filter:initParams(context, filter)
	OF_LOGI(TAG, "call initParams")
	filter:insertFloatParam("TransX", -10000, 10000, 0)
	filter:insertFloatParam("TransY", -10000, 10000, 0)
	filter:insertFloatParam("Rotate", -180, 180, 0)
	filter:insertFloatParam("Scale", 0.001, 10, 1.0)

	filter:insertBoolParam("MaskTexure", false)
	filter:insertIntParam("Opacity", 0, 100, 100)
	filter:insertIntParam("Beauty", 0, 100, 0)
	filter:insertIntParam("ThinFace", 0, 100, 0)
	filter:insertEnumParam("BlendMode", 0, { "None", "Screen", "Darken", "Lighten", "Overlay",
		"HardLight", "SoftLight", "LinearBurn", "ColorBurn", "ColorDodge", "Multiply", "Subtract", 
		"Add", "LinearLight", "LinearDodge", "Difference", "LighterColor", "DarkerColor" })
	filter:insertIntParam("BlendOpacity", 0, 100, 100)

	filter:insertIntParam("Brightness", -50, 50, 0)
	filter:insertIntParam("Contrast", -50, 50, 0)
	filter:insertIntParam("Saturation", -50, 50, 0)
	filter:insertIntParam("Sharpen", 0, 100, 0)
	filter:insertIntParam("Highlight", 0, 100, 0)
	filter:insertIntParam("Shadow", 0, 100, 0)
	filter:insertIntParam("Fade", 0, 100, 0)
	filter:insertIntParam("Temperature", -50, 50, 0)
	filter:insertIntParam("Tone", -50, 50, 0)

	filter:insertEnumParam("EnterAnim", 0, Config.enter_animation)
	filter:insertStringParam("EnterAnimDir", "")
	filter:insertFloatParam("EnterAnimDuration", 0, 10, 1)

	filter:insertEnumParam("ExitAnim", 0, Config.exit_animation)
	filter:insertStringParam("ExitAnimDir", "")
	filter:insertFloatParam("ExitAnimDuration", 0, 10, 1)

	filter:insertEnumParam("LoopAnim", 0, Config.loop_animation)
	filter:insertStringParam("LoopAnimDir", "")
	filter:insertFloatParam("LoopAnimDuration", 0, 10, 1)

	filter:insertResArrParam("EffectList", OF_ResType_Effect)

	filter:insertFloatParam("debug", 0, 0.2, 0)
	return OF_Result_Success
end

function Filter:onApplyParams(context, filter)
	OF_LOGI(TAG, "call onApplyParams")
	if self.fSetParamsByMsg == false then
		self.params.tx = filter:floatParam("TransX")
		self.params.ty = filter:floatParam("TransY")
		self.params.rot = filter:floatParam("Rotate") * math.pi / 180
		self.params.scale = filter:floatParam("Scale")
	end
	self.debug = filter:floatParam("debug")
	
	local idx =  filter:enumParam("EnterAnim") + 1
	local name = Config.enter_animation[idx]
	local effect_dir = filter:stringParam("EnterAnimDir")
	local enterAnimPath = filter:filterDir() .. "/../enter_animation/" .. name .. "/" .. name .. ".lua"
	if string.len(effect_dir) > 0 then
		local s = context:loadTextFromFile(effect_dir .. "/config.json")
		local tab = Json.JsonToTable(s)
		enterAnimPath = effect_dir .. "/" .. tab.script
	end
	if idx > 1 or string.len(effect_dir) > 0 then -- not none
		if self.animation.enter_animation then
            self.animation.enter_animation:clear(self)
        end
		self.animation.enter_animation = dofile(enterAnimPath)
		self.animation.enter_animation:init(self)
		self.animation.enter_duration = filter:floatParam("EnterAnimDuration") * 1000
		self.animation.enter_animation:setDuration(self, self.animation.enter_duration)
	else
		self.animation.enter_animation = nil
	end

	idx =  filter:enumParam("ExitAnim") + 1
	name = Config.exit_animation[idx]
	effect_dir = filter:stringParam("ExitAnimDir")
	local exitAnimPath = filter:filterDir() .. "/../exit_animation/" .. name .. "/" .. name .. ".lua"
	if string.len(effect_dir) > 0 then
		local s = context:loadTextFromFile(effect_dir .. "/config.json")
		local tab = Json.JsonToTable(s)
		exitAnimPath = effect_dir .. "/" .. tab.script
	end
	if idx > 1 or string.len(effect_dir) > 0 then -- not none
		if self.animation.exit_animation then
            self.animation.exit_animation:clear(self)
        end
		self.animation.exit_animation = dofile(exitAnimPath)
		self.animation.exit_animation:init(self)
		self.animation.exit_duration = filter:floatParam("ExitAnimDuration") * 1000
		self.animation.exit_animation:setDuration(self, self.animation.exit_duration)
	else
		self.animation.exit_animation = nil
	end

	idx =  filter:enumParam("LoopAnim") + 1
	name = Config.loop_animation[idx]
	effect_dir = filter:stringParam("LoopAnimDir")
	local loopAnimPath = filter:filterDir() .. "/../loop_animation/" .. name .. "/" .. name .. ".lua"
	if string.len(effect_dir) > 0 then
		local s = context:loadTextFromFile(effect_dir .. "/config.json")
		local tab = Json.JsonToTable(s)
		loopAnimPath = effect_dir .. "/" .. tab.script
	end
	if idx > 1 or string.len(effect_dir) > 0 then -- not none
		if self.animation.loop_animation then
            self.animation.loop_animation:clear(self)
        end
		self.animation.loop_animation = dofile(loopAnimPath)
		self.animation.loop_animation:init(self)
		self.animation.loop_duration = filter:floatParam("LoopAnimDuration") * 1000
		self.animation.loop_animation:setDuration(self, self.animation.loop_duration)
	else
		self.animation.loop_animation = nil
	end
	
	-- effect list
    local effectListTable = filter:resArrParam("EffectList")
	local paths = {}
	for i = 1, #effectListTable do
		table.insert(paths, filter:resFullPath(effectListTable[i]))
	end
	EffectList:setEffectPaths(context, paths)

	--
	--  1 - beatuy
	--  2 - thinface
	--
	self.params.blendMode = filter:enumParam("BlendMode")
	self.params.blendOpacity = filter:intParam("BlendOpacity")
	self.params.opacity = filter:intParam("Opacity")
	self.params.beauty = filter:intParam("Beauty")
	self.params.thinface = filter:intParam("ThinFace")
    self.params.brightness  = filter:intParam("Brightness")
    self.params.contrast    = filter:intParam("Contrast")
    self.params.saturation  = filter:intParam("Saturation")
    self.params.sharpen     = filter:intParam("Sharpen")
    self.params.highlight   = filter:intParam("Highlight")
    self.params.shadow      = filter:intParam("Shadow")
    self.params.fade        = filter:intParam("Fade")
    self.params.temperature = filter:intParam("Temperature")
    self.params.tone        = filter:intParam("Tone")
	EffectList:setEnabled(1, self.params.beauty > 0)
	EffectList:setEnabled(2, self.params.thinface > 0)
	EffectList:setEnabled(3, self.params.brightness  ~= 0)
    EffectList:setEnabled(4, self.params.contrast    ~= 0)
	EffectList:setEnabled(5, self.params.saturation  ~= 0)
	EffectList:setEnabled(6, self.params.sharpen     ~= 0)
	EffectList:setEnabled(7, self.params.highlight   ~= 0)
	EffectList:setEnabled(8, self.params.shadow      ~= 0)
	EffectList:setEnabled(9, self.params.fade        ~= 0)
	EffectList:setEnabled(10, self.params.temperature ~= 0)
	EffectList:setEnabled(11, self.params.tone        ~= 0)
	EffectList:sendMessage(context, 1, Json.TableToJson({ beauty = self.params.beauty }))
	EffectList:sendMessage(context, 2, Json.TableToJson({ thinface = self.params.thinface }))
	EffectList:sendMessage(context, 3, Json.TableToJson({ intensity = self.params.brightness / 50 }))
	EffectList:sendMessage(context, 4, Json.TableToJson({ intensity = self.params.contrast / 50 }))
	EffectList:sendMessage(context, 5, Json.TableToJson({ intensity = self.params.saturation / 50 }))
	EffectList:sendMessage(context, 6, Json.TableToJson({ intensity = self.params.sharpen / 100 }))
	EffectList:sendMessage(context, 7, Json.TableToJson({ intensity = self.params.highlight / 100 }))
	EffectList:sendMessage(context, 8, Json.TableToJson({ intensity = self.params.shadow / 100 }))
	EffectList:sendMessage(context, 9, Json.TableToJson({ intensity = self.params.fade / 100 }))
	EffectList:sendMessage(context, 10, Json.TableToJson({ intensity = self.params.temperature / 50 }))
	EffectList:sendMessage(context, 11, Json.TableToJson({ intensity = self.params.tone / 50 }))

	self.hasMask = filter:boolParam("MaskTexure")
	if self.hasMask == true then
		self.renderMaskPass = context:createCustomShaderPass(self.vs, self.mask_fs)
	end

	return OF_Result_Success
end

function Filter:initRenderer(context, filter)
	OF_LOGI(TAG, "call initRenderer")
	self.context = context
	self.renderPass = context:createCustomShaderPass(self.vs, self.fs)
	EffectList:init(context)
	return OF_Result_Success
end

function Filter:teardownRenderer(context, filter)
	OF_LOGI(TAG, "call teardownRenderer")
	context:destroyCustomShaderPass(self.renderPass)
	if self.renderMaskPass ~= nil then
		context:destroyCustomShaderPass(self.renderMaskPass)
	end
	context:destroyCustomShaderPass(self.blendPass)
	if self.imageTex then 
		context:releaseTexture(self.imageTex) 
		self.imageTex = nil
	end -- destroy if exist
	if self.maskTex then 
		context:releaseTexture(self.maskTex)
		self.maskTex = nil
	 end 
	EffectList:clear(context)

	if self.animation.enter_animation then
        self.animation.enter_animation:clear(self)
    end

    if self.animation.exit_animation then
        self.animation.exit_animation:clear(self)
    end

    if self.animation.loop_animation then
        self.animation.loop_animation:clear(self)
    end

	return OF_Result_Success
end

function Filter:seek(filter, timestamp)
	self.animation.params = {
		alpha = 1.0,
		position = { 0, 0, 0 },
		scale = { 1.0, 1.0, 1.0 },
		rotation = { 0.0, 0.0, 0.0 },
		localPosition = { 0, 0, 0},
		localScale = { 1.0, 1.0, 1.0 },
		localRotation = { 0.0, 0.0, 0.0 },
		renderToRT = nil
	}

	if self.animation.loop_animation then
		self.animation.loop_animation:seek(self, timestamp)
		self.animation.loop_animation:apply(self)
		return
	else
		if self.animation.enter_animation and timestamp < self.animation.enter_duration then
			self.animation.enter_animation:seek(self, timestamp)
			self.animation.enter_animation:apply(self)
			return
		end

		local exitTime = filter:duration() * 1000 - self.animation.exit_duration
		if self.animation.exit_animation and timestamp > exitTime then
			self.animation.exit_animation:seek(self, timestamp - exitTime)
			self.animation.exit_animation:apply(self)
			return
		end
	end
	return
end

function Filter:renderToOutputDirectly(context, filter, baseTex, outTex)
	local width, height = outTex.width, outTex.height
	local timestamp = filter:filterTimestamp() * 1000

	local quadRender = context:sharedQuadRender()

	local scaleMat = Matrix4f:ScaleMat(self.params.scale, self.params.scale, 1.0)
	local rotMat = Matrix4f:RotMat(0, 0, self.params.rot)
	local transMat = Matrix4f:TransMat(self.params.tx, self.params.ty, 0.0)

	local animLocalTransMat = Matrix4f:TransMat(
		self.animation.params.localPosition[1], self.animation.params.localPosition[2],
		self.animation.params.localPosition[3])
	local animLocalScaleMat = Matrix4f:ScaleMat(
		self.animation.params.localScale[1], self.animation.params.localScale[2],
		self.animation.params.localScale[3])
	local animLocalRotMat = Matrix4f:RotMat(
		self.animation.params.localRotation[1], self.animation.params.localRotation[2],
		self.animation.params.localRotation[3])

	local animTransMat = Matrix4f:TransMat(
		self.animation.params.position[1], self.animation.params.position[2], self.animation.params.position[3])
	local animScaleMat = Matrix4f:ScaleMat(
		self.animation.params.scale[1], self.animation.params.scale[2],	self.animation.params.scale[3])
		
	local animRotMat = Matrix4f:RotMat(
		self.animation.params.rotation[1], self.animation.params.rotation[2], self.animation.params.rotation[3])
	local mvpMat =
		Matrix4f:ScaleMat(2 / width, 2 / height, 1.0 ) *
		animTransMat * transMat *
		animRotMat * rotMat *
		animScaleMat * scaleMat *
		animLocalTransMat * animLocalRotMat * animLocalScaleMat *
		Matrix4f:ScaleMat(self.imageTex:width() * 0.5, self.imageTex:height() * 0.5, 1)

	
	local renderPass = self.renderPass
    if self.params.blendMode == 0 then
        context:copyTexture(baseTex, outTex)

		context:bindFBO(outTex)
		context:setBlend(true)
		context:setBlendMode(RS_BlendFunc_SRC_ALPHA, RS_BlendFunc_INV_SRC_ALPHA)
        context:setViewport(0, 0, width, height)

		local pass = self.renderPass;
		if self.maskTex ~= nil then
			pass = self.renderMaskPass;
		end
        pass:use()
        pass:setUniformMatrix4fv("uMVP", 1, 0, mvpMat.x)
        pass:setUniformTexture("uTexture0", 0, self.imageTex:textureID(), TEXTURE_2D)
		if self.maskTex ~= nil then
			pass:setUniformTexture("uTexture1", 1,  self.maskTex:textureID(), TEXTURE_2D)
		end
        pass:setUniform1f("uTileX", 1)
        pass:setUniform1f("uTileY", 1)
        pass:setUniform1f("uAnimFPS", 1)
        pass:setUniform1f("uTimestamp", math.floor(timestamp))
        pass:setUniform4f("uColor", 1.0, 1.0, 1.0, self.animation.params.alpha * self.params.opacity / 100)
        quadRender:draw(pass, false)
    else
		if self.blendPass == nil then
			self.blendPass = context:createCustomShaderPass(self.vs, self.blend_fs)
		end

		local blendTex = context:getTexture(width, height)
		context:bindFBO(blendTex:toOFTexture())
		context:setViewport(0, 0, width, height)
		context:setClearColor(0.0, 0.0, 0.0, 0.0)
		context:clearColorBuffer()
        context:setBlend(false)

		self.renderPass:use()
		self.renderPass:setUniformMatrix4fv("uMVP", 1, 0, mvpMat.x)
		self.renderPass:setUniformTexture("uTexture0", 0, self.imageTex:textureID(), TEXTURE_2D)
		self.renderPass:setUniform1f("uTileX", 1)
		self.renderPass:setUniform1f("uTileY", 1)
		self.renderPass:setUniform1f("uAnimFPS", 1)
		self.renderPass:setUniform1f("uTimestamp", math.floor(timestamp))
		self.renderPass:setUniform4f("uColor", 1.0, 1.0, 1.0, self.animation.params.alpha * self.params.opacity / 100)
		quadRender:draw(renderPass, false)

		context:bindFBO(outTex)
		context:setViewport(0, 0, width, height)

		self.blendPass:use()
		self.blendPass:setUniformMatrix4fv("uMVP", 1, 0, Matrix4f:ScaleMat(1.0, 1.0, 1.0 ).x)
		self.blendPass:setUniformTexture("uTexture0", 0, baseTex.textureID, TEXTURE_2D)
		self.blendPass:setUniformTexture("uTexture1", 1, blendTex:textureID(), TEXTURE_2D)
		self.blendPass:setUniform1f("uOpacity", self.params.blendOpacity / 100)
		self.blendPass:setUniform1i("uBlendMode", self.params.blendMode)
		quadRender:draw(self.blendPass, false)

		context:releaseTexture(blendTex)
	end
end


function Filter:renderThroughRT(context, filter, baseTex, outTex)
	local width, height = outTex.width, outTex.height
	local timestamp = filter:filterTimestamp() * 1000

	local quadRender = context:sharedQuadRender()

	local texTemp = context:createTexture(width, height)

	if self.animation.loop_animation then
		self.animation.loop_animation:applyEffect(self, texTemp:toOFTexture())
	elseif self.animation.enter_animation and timestamp < self.animation.enter_duration then
		self.animation.enter_animation:applyEffect(self, texTemp:toOFTexture())
	else
		local exitTime = filter:duration() * 1000 - self.animation.exit_duration
		if self.animation.exit_animation and timestamp > exitTime then
			self.animation.exit_animation:applyEffect(self, texTemp:toOFTexture())
		end
	end

	if self.blendPass == nil then
		self.blendPass = context:createCustomShaderPass(self.vs, self.blend_fs)
	end

	context:bindFBO(outTex)
	context:setViewport(0, 0, width, height)
	self.blendPass:use()
	self.blendPass:setUniformMatrix4fv("uMVP", 1, 0, Matrix4f:ScaleMat(1.0, 1.0, 1.0 ).x)
	self.blendPass:setUniformTexture("uTexture0", 0, baseTex.textureID, TEXTURE_2D)
	self.blendPass:setUniformTexture("uTexture1", 1, texTemp:textureID(), TEXTURE_2D)
	self.blendPass:setUniform1f("uOpacity", self.params.blendOpacity / 100)
	self.blendPass:setUniform1i("uBlendMode", self.params.blendMode)
	quadRender:draw(self.blendPass, false)

	context:destroyTexture(texTemp)
end


function Filter:applyFrame(context, filter, frameData, inTexArray, outTexArray)
	if inTexArray[2] == nil then
        context:copyTexture(inTexArray[1], outTexArray[1])
        return
    end
	if inTexArray[3] == nil then
		self.hasMask = false
    end

	local imageTexOF = inTexArray[2]
	--
	-- apply extra effects to inTexArray[2]
	--
	local imageWidth = imageTexOF.width
	local imageHeight = imageTexOF.height
	local tempTex = context:getTexture(imageWidth, imageHeight)
	if not EffectList:isEmpty() then
		EffectList:apply(context, frameData, inTexArray[2], tempTex:toOFTexture(),
			outTexArray[2], filter:filterTimestamp())
		imageTexOF = tempTex:toOFTexture()
	end

	if self.imageTex == nil then
		self.imageTex = context:createTextureRef(imageTexOF)
	else
		context:updateTextureRef(self.imageTex, imageTexOF)
	end
	
	--
	-- apply maskTex from inTexArray[3]
	--
	if self.hasMask == true and inTexArray[3] ~= nil then
		if self.maskTex == nil then
			self.maskTex = context:createTextureRef(inTexArray[3])
		else
			context:updateTextureRef(self.maskTex, inTexArray[3])
		end
	end

	local timestamp = filter:filterTimestamp() * 1000
	self.seek(self, filter, timestamp)

	if self.animation.params.renderToRT then
		self.renderThroughRT(self, context, filter, inTexArray[1], outTexArray[1])
	else
		self.renderToOutputDirectly(self, context, filter, inTexArray[1], outTexArray[1])
	end

	if tempTex then context:releaseTexture(tempTex) end

	-- debug tex
	if outTexArray[2] ~= nil then
		context:copyTexture(inTexArray[1], outTexArray[2])
	end

	return OF_Result_Success
end

function Filter:requiredFrameData(context, filter)
    if filter:intParam("ThinFace") > 0 then
        return { OF_RequiredFrameData_FaceLandmarker }
    else
		return { OF_RequiredFrameData_None }
    end
end

function Filter:readObject(context, filter, archiveIn)
	OF_LOGI(TAG, "call readObject")
	return OF_Result_Success
end

function Filter:writeObject(context, filter, archiveOut)
	OF_LOGI(TAG, "call writeObject")
	return OF_Result_Success
end

function Filter:onReceiveMessage(context, filter, msg)
	OF_LOGI(TAG, string.format("call onReceiveMessage %s", msg))
	local evt = Json.JsonToTable(msg)
	if evt.id == 1 then
		self.fSetParamsByMsg = true
		self.params.tx = evt.params[1]
		self.params.ty = evt.params[2]
		self.params.scale = evt.params[3]
		self.params.rot = evt.params[4] * math.pi / 180
	elseif evt.id == 2 then
		OF_LOGI(TAG, string.format("%d, %s", evt.id, evt.effect_dir))
		if string.len(evt.effect_dir) > 0 then
			local s = context:loadTextFromFile(evt.effect_dir .. "/config.json")
			local tab = Json.JsonToTable(s)
			self.animation.enter_animation = dofile(evt.effect_dir .. "/" .. tab.script)
			self.animation.enter_animation:init(self)
			self.animation.enter_duration = evt.duration * 1000
			self.animation.enter_animation:setDuration(self.animation.enter_duration)
		else
			self.animation.enter_animation = nil
		end
	elseif evt.id == 3 then
		OF_LOGI(TAG, string.format("%d, %s", evt.id, evt.effect_dir))
		if string.len(evt.effect_dir) > 0 then
			local s = context:loadTextFromFile(evt.effect_dir .. "/config.json")
			local tab = Json.JsonToTable(s)
			self.animation.exit_animation = dofile(evt.effect_dir .. "/" .. tab.script)
			self.animation.exit_animation:init(self)
			self.animation.exit_duration = evt.duration * 1000
			self.animation.exit_animation:setDuration(self.animation.exit_duration)
		else
			self.animation.exit_animation = nil
		end
	elseif evt.id == 4 then
		OF_LOGI(TAG, string.format("%d, %s", evt.id, evt.effect_dir))
		if string.len(evt.effect_dir) > 0 then
			local s = context:loadTextFromFile(evt.effect_dir .. "/config.json")
			local tab = Json.JsonToTable(s)
			self.animation.loop_animation = dofile(evt.effect_dir .. "/" .. tab.script)
			self.animation.loop_animation:init(self)
			self.animation.loop_duration = evt.duration * 1000
			self.animation.loop_animation:setDuration(self.animation.loop_duration)
		else
			self.animation.loop_animation = nil
		end
	end
	return ""
end

return Filter
